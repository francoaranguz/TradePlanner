import { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { DayRegister } from './components/DayRegister';
import { RiskCalculator } from './components/RiskCalculator';
import { PlanSetup } from './components/PlanSetup';
import { Integrations } from './components/Integrations';
import { Login } from './components/Login';
import { getSavedUser, logoutUser, User } from './components/utils/auth-utils';
import { isPlanConfigured } from './components/utils/plan-utils';

type Screen = 'dashboard' | 'register' | 'calculator' | 'plan-setup' | 'integrations';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Verificar si hay una sesión guardada al cargar la app
  useEffect(() => {
    const savedUser = getSavedUser();
    if (savedUser) {
      setUser(savedUser);
      
      // Si no hay plan configurado, redirigir a plan-setup
      if (!isPlanConfigured()) {
        setCurrentScreen('plan-setup');
      }
    }
    setIsLoading(false);
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
    logoutUser();
    setCurrentScreen('dashboard');
  };

  // Mostrar loading mientras se verifica la sesión
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Cargando Trading Planner...</p>
        </div>
      </div>
    );
  }

  // Si no hay usuario logueado, mostrar login
  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  const renderScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return (
          <Dashboard
            onNavigateToRegister={() => setCurrentScreen('register')}
            onNavigateToCalculator={() => setCurrentScreen('calculator')}
            onNavigateToConfig={() => setCurrentScreen('plan-setup')}
            onNavigateToIntegrations={() => setCurrentScreen('integrations')}
            user={user}
            onLogout={handleLogout}
          />
        );
      case 'register':
        return (
          <DayRegister
            onBack={() => setCurrentScreen('dashboard')}
            user={user}
          />
        );
      case 'calculator':
        return (
          <RiskCalculator
            onBack={() => setCurrentScreen('dashboard')}
            user={user}
          />
        );
      case 'plan-setup':
        return (
          <PlanSetup
            onBack={() => setCurrentScreen('dashboard')}
            user={user}
            onPlanSaved={() => setCurrentScreen('dashboard')}
          />
        );
      case 'integrations':
        return (
          <Integrations
            onBack={() => setCurrentScreen('dashboard')}
            onViewOperations={() => setCurrentScreen('dashboard')}
            user={user}
          />
        );
      default:
        return (
          <Dashboard
            onNavigateToRegister={() => setCurrentScreen('register')}
            onNavigateToCalculator={() => setCurrentScreen('calculator')}
            onNavigateToConfig={() => setCurrentScreen('plan-setup')}
            onNavigateToIntegrations={() => setCurrentScreen('integrations')}
            user={user}
            onLogout={handleLogout}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {renderScreen()}
    </div>
  );
}