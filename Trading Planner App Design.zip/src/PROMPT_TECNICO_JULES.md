# Trading Planner - Prompt Técnico Completo para Jules AI

## Instrucciones Técnicas Generales

Crea una aplicación web completa llamada "Trading Planner" usando **React 18 + TypeScript + Tailwind CSS v4**. La aplicación debe ser completamente responsive, en **español chileno**, y usar **navegación por estados** (no React Router).

### Stack Tecnológico Requerido
```typescript
// Imports principales que debes usar
import { useState, useEffect } from 'react';
import { Lucide React icons } from 'lucide-react';
import { Recharts } from 'recharts';
import { ShadCN UI components } from './components/ui/*';
```

## Estructura de Archivos Exacta

```
/
├── App.tsx                          # Componente principal con navegación por estados
├── styles/
│   └── globals.css                  # CSS global con variables de Tailwind v4
├── components/
│   ├── Dashboard.tsx                # Pantalla principal
│   ├── Login.tsx                    # Pantalla de autenticación OAuth
│   ├── DayRegister.tsx              # Registro diario de trading
│   ├── RiskCalculator.tsx           # Calculadora de gestión de riesgo
│   ├── PlanSetup.tsx                # Configuración del plan de trading
│   ├── Integrations.tsx             # Gestión de integración MT5
│   ├── UserMenu.tsx                 # Menú desplegable del usuario
│   ├── SummaryCards.tsx             # Cards de resumen para dashboard
│   ├── TradingOperations.tsx        # Visualización de operaciones MT5
│   ├── constants/
│   │   └── app-constants.ts         # Constantes de la aplicación
│   ├── figma/
│   │   └── ImageWithFallback.tsx    # Componente protegido (NO MODIFICAR)
│   ├── ui/                          # Componentes ShadCN (usar existentes)
│   │   ├── button.tsx, card.tsx, input.tsx, etc.
│   └── utils/
│       ├── auth-utils.ts            # Utilidades de autenticación
│       ├── plan-utils.ts            # Gestión del plan de trading
│       ├── integration-utils.ts     # Utilidades de integración MT5
│       ├── withdrawal-utils.ts      # Gestión de retiros
│       ├── risk-calculator-utils.ts # Cálculos de riesgo
│       └── chart-utils.ts           # Utilidades para gráficos
```

## Configuración CSS Global (styles/globals.css)

```css
@custom-variant dark (&:is(.dark *));

:root {
  --font-size: 14px;
  --background: #000000;
  --foreground: #ffffff;
  --card: #1a1a1a;
  --card-foreground: #ffffff;
  --primary: #ffd700;
  --primary-foreground: #000000;
  --secondary: #2a2a2a;
  --secondary-foreground: #ffffff;
  --muted: #333333;
  --muted-foreground: #cccccc;
  --destructive: #ff4444;
  --destructive-foreground: #ffffff;
  --success: #00ff7f;
  --success-foreground: #000000;
  --input-background: #ffffff;
  --input-foreground: #000000;
  --font-weight-medium: 500;
  --font-weight-normal: 400;
  --radius: 0.625rem;
}

/* Estilos específicos para inputs negros */
input[type="number"],
input[type="text"],
input[type="email"],
input[type="password"] {
  color: #000000 !important;
}

[data-slot="select-trigger"] {
  color: #000000 !important;
}

/* Tipografía base responsive */
html {
  font-size: var(--font-size);
}

h1 { font-size: var(--text-2xl); font-weight: var(--font-weight-medium); }
h2 { font-size: var(--text-xl); font-weight: var(--font-weight-medium); }
h3 { font-size: var(--text-lg); font-weight: var(--font-weight-medium); }
h4 { font-size: var(--text-base); font-weight: var(--font-weight-medium); }
p { font-size: var(--text-base); font-weight: var(--font-weight-normal); }
```

## App.tsx - Componente Principal

```typescript
import { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { DayRegister } from './components/DayRegister';
import { RiskCalculator } from './components/RiskCalculator';
import { PlanSetup } from './components/PlanSetup';
import { Integrations } from './components/Integrations';
import { Login } from './components/Login';
import { getSavedUser, logoutUser, User } from './components/utils/auth-utils';
import { isPlanConfigured } from './components/utils/plan-utils';

type Screen = 'dashboard' | 'register' | 'calculator' | 'plan-setup' | 'integrations';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = getSavedUser();
    if (savedUser) {
      setUser(savedUser);
      if (!isPlanConfigured()) {
        setCurrentScreen('plan-setup');
      }
    }
    setIsLoading(false);
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
    logoutUser();
    setCurrentScreen('dashboard');
  };

  // Loading screen
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Cargando Trading Planner...</p>
        </div>
      </div>
    );
  }

  // Login screen
  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  // Navigation logic
  const renderScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return (
          <Dashboard
            onNavigateToRegister={() => setCurrentScreen('register')}
            onNavigateToCalculator={() => setCurrentScreen('calculator')}
            onNavigateToConfig={() => setCurrentScreen('plan-setup')}
            onNavigateToIntegrations={() => setCurrentScreen('integrations')}
            user={user}
            onLogout={handleLogout}
          />
        );
      case 'register':
        return <DayRegister onBack={() => setCurrentScreen('dashboard')} user={user} />;
      case 'calculator':
        return <RiskCalculator onBack={() => setCurrentScreen('dashboard')} user={user} />;
      case 'plan-setup':
        return (
          <PlanSetup
            onBack={() => setCurrentScreen('dashboard')}
            user={user}
            onPlanSaved={() => setCurrentScreen('dashboard')}
          />
        );
      case 'integrations':
        return (
          <Integrations
            onBack={() => setCurrentScreen('dashboard')}
            onViewOperations={() => setCurrentScreen('dashboard')}
            user={user}
          />
        );
      default:
        return (
          <Dashboard
            onNavigateToRegister={() => setCurrentScreen('register')}
            onNavigateToCalculator={() => setCurrentScreen('calculator')}
            onNavigateToConfig={() => setCurrentScreen('plan-setup')}
            onNavigateToIntegrations={() => setCurrentScreen('integrations')}
            user={user}
            onLogout={handleLogout}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {renderScreen()}
    </div>
  );
}
```

## Utilidades Específicas Requeridas

### auth-utils.ts
```typescript
export interface User {
  email: string;
  name: string;
  avatar?: string;
  provider: 'google' | 'apple' | 'facebook';
}

export const saveUser = (user: User): void => {
  localStorage.setItem('trading_planner_user', JSON.stringify(user));
};

export const getSavedUser = (): User | null => {
  const saved = localStorage.getItem('trading_planner_user');
  return saved ? JSON.parse(saved) : null;
};

export const logoutUser = (): void => {
  localStorage.removeItem('trading_planner_user');
};

// Mock OAuth functions for demo
export const signInWithGoogle = async (): Promise<User> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        email: 'demo@trader.com',
        name: 'Demo Trader',
        provider: 'google'
      });
    }, 1500);
  });
};

export const signInWithApple = async (): Promise<User> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        email: 'demo@trader.com',
        name: 'Demo Trader',
        provider: 'apple'
      });
    }, 1500);
  });
};

export const signInWithFacebook = async (): Promise<User> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        email: 'demo@trader.com',
        name: 'Demo Trader',
        provider: 'facebook'
      });
    }, 1500);
  });
};
```

### plan-utils.ts
```typescript
export interface TradingPlan {
  capitalInicial: number;
  metaDiariaPercent: number;
  porcentajeRetiro: number; // 0.7 = 70%
  porcentajeAcumulacion: number; // 0.3 = 30%
  fechaCreacion: string;
}

export const savePlan = (plan: TradingPlan): void => {
  localStorage.setItem('trading_planner_plan', JSON.stringify(plan));
};

export const getSavedPlan = (): TradingPlan | null => {
  const saved = localStorage.getItem('trading_planner_plan');
  return saved ? JSON.parse(saved) : null;
};

export const isPlanConfigured = (): boolean => {
  return getSavedPlan() !== null;
};

export const calculateDailyMeta = (capitalInicial: number, porcentaje: number): number => {
  return (capitalInicial * porcentaje) / 100;
};

export const validatePlan = (plan: Partial<TradingPlan>): { valid: boolean; message: string } => {
  if (!plan.capitalInicial || plan.capitalInicial <= 0) {
    return { valid: false, message: 'Capital inicial debe ser mayor a 0' };
  }
  
  if (!plan.metaDiariaPercent || plan.metaDiariaPercent <= 0 || plan.metaDiariaPercent > 50) {
    return { valid: false, message: 'Meta diaria debe estar entre 0.01% y 50%' };
  }
  
  if ((plan.porcentajeRetiro || 0) + (plan.porcentajeAcumulacion || 0) !== 1) {
    return { valid: false, message: 'La suma de porcentajes debe ser 100%' };
  }
  
  return { valid: true, message: '' };
};
```

### withdrawal-utils.ts
```typescript
export interface WithdrawalRecord {
  fecha: string; // YYYY-MM-DD
  monto: number;
  tipo: 'profit' | 'balance';
  notas?: string;
}

export const saveWithdrawal = (withdrawal: WithdrawalRecord): void => {
  const existing = getWithdrawals();
  existing.push(withdrawal);
  localStorage.setItem('trading_planner_withdrawals', JSON.stringify(existing));
};

export const getWithdrawals = (): WithdrawalRecord[] => {
  const saved = localStorage.getItem('trading_planner_withdrawals');
  return saved ? JSON.parse(saved) : [];
};

export const getWithdrawalsByDate = (fecha: string): WithdrawalRecord[] => {
  return getWithdrawals().filter(w => w.fecha === fecha);
};

export const validateWithdrawal = (monto: number, tipo: 'profit' | 'balance'): { valid: boolean; message: string } => {
  if (monto <= 0) {
    return { valid: false, message: 'El monto debe ser mayor a 0' };
  }
  
  if (monto > 100000) {
    return { valid: false, message: 'El monto parece demasiado alto' };
  }
  
  return { valid: true, message: '' };
};
```

### integration-utils.ts
```typescript
export interface MT5Integration {
  isConnected: boolean;
  apiKey?: string;
  lastSync?: string;
  accountNumber?: string;
  serverName?: string;
}

export const getMT5Status = (): MT5Integration => {
  const saved = localStorage.getItem('trading_planner_mt5');
  return saved ? JSON.parse(saved) : { isConnected: false };
};

export const saveMT5Status = (status: MT5Integration): void => {
  localStorage.setItem('trading_planner_mt5', JSON.stringify(status));
};

export const generateApiKey = (): string => {
  return 'TP_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

export const validateConnection = async (apiKey: string): Promise<{ success: boolean; message: string }> => {
  // Simulación de validación
  return new Promise((resolve) => {
    setTimeout(() => {
      if (apiKey.startsWith('TP_')) {
        resolve({ success: true, message: 'Conexión establecida exitosamente' });
      } else {
        resolve({ success: false, message: 'API Key inválida' });
      }
    }, 2000);
  });
};

// Mock trading operations
export interface TradingOperation {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  volume: number;
  openPrice: number;
  closePrice?: number;
  profit: number;
  openTime: string;
  closeTime?: string;
  status: 'OPEN' | 'CLOSED';
}

export const getMockOperations = (): TradingOperation[] => {
  return [
    {
      id: '1001',
      symbol: 'EURUSD',
      type: 'BUY',
      volume: 0.1,
      openPrice: 1.0850,
      closePrice: 1.0875,
      profit: 25.00,
      openTime: '2024-01-15 09:30:00',
      closeTime: '2024-01-15 11:45:00',
      status: 'CLOSED'
    },
    {
      id: '1002',
      symbol: 'GBPUSD',
      type: 'SELL',
      volume: 0.05,
      openPrice: 1.2650,
      profit: -15.50,
      openTime: '2024-01-15 14:20:00',
      status: 'OPEN'
    }
  ];
};
```

### risk-calculator-utils.ts
```typescript
export interface RiskCalculation {
  accountBalance: number;
  riskPercent: number;
  entryPrice: number;
  stopLoss: number;
  lotSize: number;
  riskAmount: number;
  pipValue: number;
  pips: number;
}

export const calculateLotSize = (
  accountBalance: number,
  riskPercent: number,
  entryPrice: number,
  stopLoss: number,
  pipValue: number = 10 // USD per pip for standard lot
): RiskCalculation => {
  const riskAmount = (accountBalance * riskPercent) / 100;
  const pips = Math.abs(entryPrice - stopLoss) * 10000; // Para pares principales
  const lotSize = riskAmount / (pips * pipValue);
  
  return {
    accountBalance,
    riskPercent,
    entryPrice,
    stopLoss,
    lotSize: Math.round(lotSize * 100) / 100, // Redondear a 2 decimales
    riskAmount,
    pipValue,
    pips: Math.round(pips)
  };
};

export const validateRiskInputs = (
  balance: number,
  risk: number,
  entry: number,
  stopLoss: number
): { valid: boolean; message: string } => {
  if (balance <= 0) {
    return { valid: false, message: 'El balance debe ser mayor a 0' };
  }
  
  if (risk <= 0 || risk > 10) {
    return { valid: false, message: 'El riesgo debe estar entre 0.1% y 10%' };
  }
  
  if (entry <= 0 || stopLoss <= 0) {
    return { valid: false, message: 'Los precios deben ser mayores a 0' };
  }
  
  if (Math.abs(entry - stopLoss) < 0.0001) {
    return { valid: false, message: 'La diferencia entre entrada y stop loss es muy pequeña' };
  }
  
  return { valid: true, message: '' };
};
```

### chart-utils.ts
```typescript
export interface ChartDataPoint {
  fecha: string;
  profit: number;
  acumulado: number;
  meta: number;
}

export const generateMockChartData = (): ChartDataPoint[] => {
  const data: ChartDataPoint[] = [];
  let acumulado = 0;
  const meta = 157.50; // Meta diaria ejemplo
  
  // Generar datos de los últimos 30 días
  for (let i = 29; i >= 0; i--) {
    const fecha = new Date();
    fecha.setDate(fecha.getDate() - i);
    
    // Profit aleatorio entre -50 y +200
    const profit = Math.random() * 250 - 50;
    acumulado += profit;
    
    data.push({
      fecha: fecha.toLocaleDateString('es-CL', { month: 'short', day: 'numeric' }),
      profit: Math.round(profit * 100) / 100,
      acumulado: Math.round(acumulado * 100) / 100,
      meta
    });
  }
  
  return data;
};

export const calculateProfitStats = (data: ChartDataPoint[]) => {
  const profits = data.map(d => d.profit);
  const totalProfit = profits.reduce((sum, p) => sum + p, 0);
  const avgProfit = totalProfit / profits.length;
  const maxProfit = Math.max(...profits);
  const minProfit = Math.min(...profits);
  const winRate = (profits.filter(p => p > 0).length / profits.length) * 100;
  
  return {
    totalProfit: Math.round(totalProfit * 100) / 100,
    avgProfit: Math.round(avgProfit * 100) / 100,
    maxProfit: Math.round(maxProfit * 100) / 100,
    minProfit: Math.round(minProfit * 100) / 100,
    winRate: Math.round(winRate * 10) / 10
  };
};
```

## Constantes de la Aplicación

### constants/app-constants.ts
```typescript
export const APP_CONFIG = {
  name: 'Trading Planner',
  version: '1.0.0',
  defaultCapital: 15750.00,
  defaultMetaPercent: 1.0, // 1%
  defaultRetiroPercent: 0.7, // 70%
  defaultAcumulacionPercent: 0.3, // 30%
};

export const MOTIVATIONAL_MESSAGES = [
  'La disciplina es la clave del éxito en el trading',
  'Cada día es una nueva oportunidad para crecer',
  'La paciencia y la consistencia generan resultados',
  'Maneja tu riesgo, maneja tu futuro',
  'El trading exitoso es 90% psicología y 10% técnica'
];

export const MT5_PLUGIN_CONFIG = {
  downloadUrl: 'https://example.com/mt5-plugin.zip',
  version: '2.1.0',
  fileName: 'TradingPlanner_MT5_Plugin.zip',
  installGuide: [
    'Descarga el archivo ZIP del plugin',
    'Extrae el contenido en la carpeta MQL5/Experts/ de tu MT5',
    'Reinicia MetaTrader 5',
    'Arrastra el Expert Advisor al gráfico',
    'Configura tu API Key en los parámetros',
    'Permite el trading automático'
  ]
};

export const OAUTH_PROVIDERS = {
  google: {
    name: 'Google',
    icon: 'chrome', // Lucide icon name
    color: 'bg-white text-black hover:bg-gray-100'
  },
  apple: {
    name: 'Apple',  
    icon: 'apple',
    color: 'bg-black text-white hover:bg-gray-800'
  },
  facebook: {
    name: 'Facebook',
    icon: 'facebook', 
    color: 'bg-blue-600 text-white hover:bg-blue-700'
  }
};
```

## Especificaciones de Componentes Principales

### Dashboard.tsx - Estructura Required
```typescript
interface DashboardProps {
  onNavigateToRegister: () => void;
  onNavigateToCalculator: () => void;
  onNavigateToConfig: () => void;
  onNavigateToIntegrations: () => void;
  user: User;
  onLogout: () => void;
}

// Debe incluir:
// - Header con logo, título y UserMenu
// - Mensaje motivacional aleatorio
// - Gráfico de progreso (Recharts)
// - Cards de acciones rápidas
// - Resumen de estadísticas del día
// - Integración con MT5 (mostrar operaciones si está conectado)
```

### DayRegister.tsx - Funcionalidades Required
```typescript
interface DayRegisterProps {
  onBack: () => void;
  user: User | null;
}

// Debe incluir:
// - Formulario para saldo real
// - Cálculos automáticos (profit total, retiro, acumulación)
// - Consejo psicológico sobre pérdidas/ganancias
// - Sistema de evaluación (success/warning/danger)
// - Control de retiros con validación
// - Mensajes motivacionales según rendimiento
```

### RiskCalculator.tsx - Cálculos Required
```typescript
interface RiskCalculatorProps {
  onBack: () => void;
  user: User | null;
}

// Debe incluir:
// - Inputs: Balance, % riesgo, precio entrada, stop loss
// - Cálculo de tamaño de lote en tiempo real
// - Validación de inputs
// - Resultados: Lote recomendado, riesgo en USD, pips
// - Historial de cálculos previos
```

### Login.tsx - OAuth Integration
```typescript
interface LoginProps {
  onLogin: (user: User) => void;
}

// Debe incluir:
// - Botones para Google, Apple, Facebook
// - Loading states durante autenticación
// - Manejo de errores
// - Diseño centrado y responsive
```

### PlanSetup.tsx - Configuración Required
```typescript
interface PlanSetupProps {
  onBack: () => void;
  user: User | null;  
  onPlanSaved: () => void;
}

// Debe incluir:
// - Input capital inicial
// - Input meta diaria (%)
// - Sliders para distribución profit (retiro/acumulación)
// - Validación de plan
// - Persistencia en localStorage
```

### Integrations.tsx - MT5 Management
```typescript
interface IntegrationsProps {
  onBack: () => void;
  onViewOperations: () => void;
  user: User | null;
}

// Debe incluir:
// - Estado de conexión MT5
// - Generación de API Key
// - Botón descarga plugin ZIP
// - Pasos de instalación detallados
// - Validación de conexión
// - Mostrar operaciones si está conectado
```

## Reglas de Estilo Específicas

### Paleta de Colores Exacta
```css
/* Usar estas clases Tailwind específicamente */
.bg-primary     /* Amarillo #ffd700 */
.text-success   /* Verde #00ff7f */
.text-destructive /* Rojo #ff4444 */
.bg-background  /* Negro #000000 */
.bg-card        /* Gris oscuro #1a1a1a */
.text-muted-foreground /* Gris claro #cccccc */
```

### Componentes UI Requeridos
```typescript
// Usar exclusivamente estos componentes ShadCN:
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { Separator } from './ui/separator';
import { Progress } from './ui/progress';
import { Textarea } from './ui/textarea';
import { Switch } from './ui/switch';
import { Slider } from './ui/slider';
```

### Iconografía Required
```typescript
// Usar exclusivamente Lucide React icons:
import { 
  TrendingUp, Calculator, Settings, Plug, 
  ArrowLeft, Calendar, DollarSign, 
  CheckCircle, AlertTriangle, AlertCircle,
  User, LogOut, Download, Key,
  Chrome, Apple, Facebook 
} from 'lucide-react';
```

### Responsive Breakpoints
```css
/* Usar estas clases para responsive */
.grid-cols-1 md:grid-cols-2 lg:grid-cols-3  /* Cards layout */
.flex-col md:flex-row                        /* Mobile-first flex */
.text-sm md:text-base                        /* Responsive text */
.p-4 md:p-6                                  /* Responsive padding */
```

## Funcionalidades Específicas Obligatorias

### 1. Navegación por Estados
- NO usar React Router
- Manejar navegación con useState<Screen>
- Todas las pantallas deben tener botón "Atrás"
- Mantener estado entre navegaciones

### 2. Persistencia de Datos
- Usar localStorage para todo
- Datos de usuario: `trading_planner_user`
- Plan de trading: `trading_planner_plan`
- Retiros: `trading_planner_withdrawals`
- Estado MT5: `trading_planner_mt5`

### 3. Validaciones Required
- Todos los formularios deben validar inputs
- Mostrar mensajes de error específicos
- Deshabilitar botones durante validación
- Estados de loading para operaciones async

### 4. Responsive Design
- Mobile-first approach
- Breakpoints: sm, md, lg, xl
- Grid adaptativo para cards
- Texto responsive
- Touch-friendly buttons (min 44px)

### 5. Estados de Carga
- Loading spinner para autenticación
- Estados disabled para botones
- Skeleton loading para datos
- Error boundaries para fallos

### 6. Formato Chileno
- Números: toLocaleString('es-CL')
- Fechas: toLocaleDateString('es-CL')
- Moneda con símbolo $
- Separador miles con punto

### 7. Mock Data para Demo
- Operaciones de trading simuladas
- Datos de gráfico de últimos 30 días
- Usuarios demo para OAuth
- Estados de conexión simulados

## Reglas de Implementación Críticas

1. **NO modificar componentes UI de ShadCN** - usar tal como están
2. **Implementar React.forwardRef** en componentes personalizados si es necesario
3. **Usar colores CSS variables** - no hardcodear hex codes
4. **Inputs siempre con texto negro** - aplicar !important si es necesario
5. **Validar todos los inputs** - nunca confiar en datos del usuario
6. **Manejar estados de error** - siempre tener fallbacks
7. **Usar tipado TypeScript estricto** - definir todas las interfaces
8. **Implementar loading states** - para mejor UX
9. **Responsive first** - diseñar para móvil primero
10. **Persistencia consistente** - usar localStorage para todo

Este prompt técnico contiene todas las especificaciones necesarias para implementar Trading Planner completamente desde cero con Jules AI.