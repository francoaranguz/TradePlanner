# 🚀 PROMPT PARA IDX - DESARROLLO BACKEND TRADING PLANNER

## 📋 RESUMEN EJECUTIVO

Necesito desarrollar el **backend completo** para "Trading Planner", una aplicación web profesional de gestión de trading ya **completamente desarrollada en el frontend** usando React + Tailwind CSS. El frontend está 100% funcional con localStorage, pero necesita migrar a un backend real con **Supabase + Vercel**.

**FRONTEND COMPLETADO ✅:**
- Aplicación responsive (desktop/móvil) 
- Sistema de autenticación local
- Dashboard con gráficos interactivos
- Registro de días de trading
- Calculadora de riesgo/lotes
- Configuración de planes
- Pantalla de integraciones MT5
- Diseño moderno negro/amarillo/verde/rojo

**OBJETIVO:** Crear backend que reemplace localStorage y agregue funcionalidades avanzadas.

---

## 🎯 STACK TECNOLÓGICO REQUERIDO

### **Frontend (YA DESARROLLADO)**
- ✅ React 18 + TypeScript
- ✅ Tailwind CSS v4
- ✅ Shadcn/ui components
- ✅ Recharts para gráficos
- ✅ Responsive design completo

### **Backend (A DESARROLLAR)**
- 🔥 **Supabase** (Base de datos + Auth + Storage)
- 🔥 **Vercel** (Deployment + Edge Functions)
- 🔥 **TypeScript** (Tipado completo)
- 🔥 **API RESTful** o **tRPC**

---

## 📊 ESTRUCTURA DE DATOS ACTUAL (FRONTEND)

### **1. Usuario (Auth)**
```typescript
interface User {
  id: string;
  name: string;
  email: string;
  createdAt: string;
}
```

### **2. Plan de Trading**
```typescript
interface TradingPlan {
  capitalInicial: number;
  metaDiariaPercent: number;
  createdAt: string;
}
```

### **3. Registro Diario**
```typescript
interface DayRecord {
  id: string;
  fecha: string;
  saldoReal: number;
  profit: number;
  metaAlcanzada: boolean;
  notas?: string;
  retiros: Withdrawal[];
}

interface Withdrawal {
  id: string;
  monto: number;
  tipo: 'profit' | 'balance';
  fecha: string;
  descripcion?: string;
}
```

### **4. Integración MT5**
```typescript
interface MT5Integration {
  isActive: boolean;
  apiKey?: string;
  lastSync?: string;
  status: 'connected' | 'disconnected' | 'error';
}
```

### **5. Operaciones Trading (Futuro MT5)**
```typescript
interface TradingOperation {
  id: string;
  symbol: string;
  type: 'buy' | 'sell';
  lotSize: number;
  openPrice: number;
  closePrice?: number;
  profit?: number;
  status: 'open' | 'closed';
  openTime: string;
  closeTime?: string;
}
```

---

## 🎨 FUNCIONALIDADES DEL FRONTEND

### **Dashboard Principal**
- ✅ Mensajes motivacionales con proyecciones
- ✅ Gráfico interactivo (diario/semanal/mensual) 
- ✅ Tarjetas de resumen (balance, profit, meta)
- ✅ Navegación responsive con menú hamburguesa
- ✅ Exportación a Excel

### **Registro del Día**
- ✅ Formulario de saldo real con validaciones
- ✅ Cálculo automático de profit/pérdida
- ✅ Sistema de retiros (profit vs balance total)
- ✅ Historial de registros anteriores

### **Calculadora de Riesgo**
- ✅ Cálculo de tamaño de lote basado en % de riesgo
- ✅ Múltiples pares de divisas
- ✅ Conversión automática de monedas
- ✅ Historial de cálculos

### **Plan Setup**
- ✅ Configuración de capital inicial
- ✅ Meta diaria en porcentaje
- ✅ Proyecciones automáticas (1-5 años)
- ✅ Validaciones y guardado

### **Integraciones**
- ✅ Gestión de plugin MT5
- ✅ Descarga de ZIP, API Key
- ✅ Pasos de instalación detallados
- ✅ Estado de conexión

### **Autenticación**
- ✅ Login/logout local
- ✅ Persistencia de sesión
- ✅ Protección de rutas

---

## 🔧 REQUERIMIENTOS DEL BACKEND

### **1. MIGRACIÓN DE DATOS**
- Convertir todas las funciones de `localStorage` a calls de API
- Mantener la misma estructura de datos
- Sincronización automática frontend ↔ backend

### **2. BASE DE DATOS SUPABASE**

#### **Tablas Principales:**
```sql
-- Usuarios
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR UNIQUE NOT NULL,
  name VARCHAR NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Planes de trading
CREATE TABLE trading_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  capital_inicial DECIMAL NOT NULL,
  meta_diaria_percent DECIMAL NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Registros diarios
CREATE TABLE day_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  fecha DATE NOT NULL,
  saldo_real DECIMAL NOT NULL,
  profit DECIMAL NOT NULL,
  meta_alcanzada BOOLEAN NOT NULL,
  notas TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, fecha)
);

-- Retiros
CREATE TABLE withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  day_record_id UUID REFERENCES day_records(id) ON DELETE CASCADE,
  monto DECIMAL NOT NULL,
  tipo VARCHAR CHECK (tipo IN ('profit', 'balance')),
  descripcion TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Integraciones MT5
CREATE TABLE mt5_integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  is_active BOOLEAN DEFAULT FALSE,
  api_key VARCHAR,
  last_sync TIMESTAMPTZ,
  status VARCHAR DEFAULT 'disconnected',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Operaciones de trading (futuro)
CREATE TABLE trading_operations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  symbol VARCHAR NOT NULL,
  type VARCHAR CHECK (type IN ('buy', 'sell')),
  lot_size DECIMAL NOT NULL,
  open_price DECIMAL NOT NULL,
  close_price DECIMAL,
  profit DECIMAL,
  status VARCHAR DEFAULT 'open',
  open_time TIMESTAMPTZ NOT NULL,
  close_time TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### **Row Level Security (RLS):**
```sql
-- Habilitar RLS en todas las tablas
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE trading_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE day_records ENABLE ROW LEVEL SECURITY;
-- ... etc para todas las tablas

-- Políticas de seguridad (users solo ven sus datos)
CREATE POLICY "Users can only see own data" ON trading_plans
  FOR ALL USING (auth.uid() = user_id);
-- ... políticas similares para todas las tablas
```

### **3. AUTENTICACIÓN SUPABASE**
- Migrar sistema de auth local a Supabase Auth
- Mantener flujo de login/logout existente
- Sesiones automáticas con refresh tokens
- Validación de email opcional

### **4. API ENDPOINTS NECESARIOS**

#### **Auth:**
- `POST /auth/login` - Login con email/password
- `POST /auth/logout` - Logout
- `GET /auth/user` - Obtener usuario actual

#### **Trading Plans:**
- `GET /api/plans` - Obtener plan del usuario
- `POST /api/plans` - Crear/actualizar plan
- `DELETE /api/plans` - Eliminar plan

#### **Day Records:**
- `GET /api/records` - Obtener registros del usuario
- `POST /api/records` - Crear registro diario
- `PUT /api/records/:id` - Actualizar registro
- `DELETE /api/records/:id` - Eliminar registro

#### **Withdrawals:**
- `GET /api/withdrawals` - Obtener retiros del usuario
- `POST /api/withdrawals` - Crear retiro
- `DELETE /api/withdrawals/:id` - Eliminar retiro

#### **Analytics:**
- `GET /api/analytics/summary` - Datos para SummaryCards
- `GET /api/analytics/chart` - Datos para gráficos
- `GET /api/analytics/projections` - Proyecciones futuras

#### **MT5 Integration:**
- `GET /api/mt5/status` - Estado de integración
- `POST /api/mt5/connect` - Conectar MT5
- `POST /api/mt5/disconnect` - Desconectar MT5
- `GET /api/mt5/operations` - Obtener operaciones

### **5. ARCHIVOS FRONTEND A MODIFICAR**

#### **Utils que necesitan migración:**
- `components/utils/auth-utils.ts` → Supabase Auth
- `components/utils/plan-utils.ts` → API calls
- `components/utils/chart-utils.ts` → API data fetching
- `components/utils/integration-utils.ts` → MT5 API calls
- `components/utils/withdrawal-utils.ts` → API calls

#### **Componentes que necesitan API integration:**
- `components/Dashboard.tsx` → Fetch analytics data
- `components/DayRegister.tsx` → CRUD operations
- `components/PlanSetup.tsx` → Plan management
- `components/SummaryCards.tsx` → Real-time data
- `components/Integrations.tsx` → MT5 management
- `components/Login.tsx` → Supabase auth

---

## 🚀 PLAN DE IMPLEMENTACIÓN

### **FASE 1: Setup Inicial**
1. Configurar proyecto Supabase
2. Configurar Vercel deployment
3. Setup de tablas y RLS policies
4. Configuración de Auth

### **FASE 2: Migración Auth**
1. Reemplazar auth local con Supabase Auth
2. Mantener flujo existente del frontend
3. Testing de login/logout

### **FASE 3: API Core**
1. Endpoints para trading plans
2. Endpoints para day records
3. Endpoints para withdrawals
4. Testing con frontend existente

### **FASE 4: Analytics & Charts**
1. Endpoints de analytics
2. Optimización de queries
3. Cache estratégico
4. Real-time updates

### **FASE 5: MT5 Integration**
1. Sistema de API keys
2. Webhook receivers (futuro)
3. Operations management
4. Error handling

### **FASE 6: Performance & Production**
1. Optimizaciones de DB
2. Monitoring y logs
3. Backup strategies
4. Security audit

---

## 🔒 CONSIDERACIONES DE SEGURIDAD

1. **Row Level Security** en todas las tablas
2. **API Rate limiting** 
3. **Input validation** en todos los endpoints
4. **CORS** configuration para frontend
5. **Environment variables** para secrets
6. **SQL injection** prevention
7. **Authentication middleware** en todas las rutas protegidas

---

## 📱 DATOS DE PRUEBA NECESARIOS

### **Usuario de Prueba:**
```json
{
  "email": "trader@test.com",
  "name": "Trading Test",
  "password": "TestPassword123"
}
```

### **Plan de Prueba:**
```json
{
  "capitalInicial": 10000,
  "metaDiariaPercent": 2
}
```

### **Registros de Prueba:**
- 30 días de datos históricos
- Variación realista de profits/losses
- Algunos retiros de prueba

---

## 🎯 RESULTADO ESPERADO

Al finalizar tendré:

1. ✅ **Backend completo** en Supabase + Vercel
2. ✅ **Frontend migrado** sin cambios visuales
3. ✅ **Base de datos** relacional optimizada
4. ✅ **Autenticación** real con Supabase Auth
5. ✅ **APIs** RESTful documentadas
6. ✅ **Deployment** automático en Vercel
7. ✅ **Seguridad** enterprise-level
8. ✅ **Escalabilidad** para múltiples usuarios

---

## 📂 ESTRUCTURA DE ARCHIVOS FRONTEND ACTUAL

```
├── App.tsx (Entry point - navigation logic)
├── components/
│   ├── Dashboard.tsx (Main dashboard with charts)
│   ├── DayRegister.tsx (Daily trading record form)
│   ├── Login.tsx (Authentication component)
│   ├── PlanSetup.tsx (Trading plan configuration)
│   ├── RiskCalculator.tsx (Lot size calculator)
│   ├── Integrations.tsx (MT5 integration management)
│   ├── SummaryCards.tsx (Analytics cards)
│   ├── TradingOperations.tsx (Future MT5 operations)
│   ├── UserMenu.tsx (User dropdown menu)
│   ├── constants/app-constants.ts (App constants)
│   ├── ui/ (Shadcn components - 50+ files)
│   └── utils/ (Local storage utilities - TO MIGRATE)
│       ├── auth-utils.ts
│       ├── chart-utils.ts
│       ├── integration-utils.ts
│       ├── plan-utils.ts
│       ├── risk-calculator-utils.ts
│       └── withdrawal-utils.ts
├── styles/globals.css (Tailwind + custom styling)
```

---

## 💡 NOTAS IMPORTANTES

1. **El frontend NO necesita cambios visuales** - solo migrar lógica de datos
2. **Mantener la misma UX** - los usuarios no deben notar diferencias
3. **Optimizar para español chileno** - formatos de números, fechas, etc.
4. **Preparar para MT5 integration** - estructura para futuras operaciones reales
5. **Escalabilidad** - diseñar para 1000+ usuarios simultáneos

---

## 🚨 PRIORIDADES

1. **CRÍTICO:** Auth migration (sin esto no funciona nada)
2. **ALTO:** Trading plans & day records (core functionality)
3. **MEDIO:** Analytics & charts (user experience)
4. **BAJO:** MT5 integration (futuro)

---

**¿Listo para convertir este frontend completo en una aplicación full-stack profesional?** 

Necesito que implementes el backend manteniendo toda la funcionalidad existente del frontend, pero con datos reales en Supabase en lugar de localStorage.