# Trading Planner - Prompt Completo del Proyecto

## Descripción General
Crea una aplicación web llamada "Trading Planner" con estilo moderno, profesional y minimalista, completamente responsive para desktop y móvil, en **español chileno**.

## Paleta de Colores Específica
- **Negro (#000000)**: Fondos base y backgrounds
- **Amarillo (#ffd700)**: Color primario para destacados, botones principales y elementos de acción
- **Verde (#00ff7f)**: Éxitos, profit, progreso positivo y confirmaciones
- **Rojo (#ff4444)**: Alertas, pérdidas, errores y elementos destructivos
- **Grises**: Varios tonos para elementos secundarios, bordes y texto muted

## Funcionalidades Principales

### 1. Sistema de Autenticación
- **Login con OAuth**: Integración con Google, Apple y Facebook
- **Persistencia de sesión**: Guarda datos del usuario en localStorage
- **Estado de loading**: Pantalla de carga mientras verifica sesión
- **Logout**: Limpia sesión y redirige al login

### 2. Dashboard Principal
- **Header con navegación**: Logo, título y menú de usuario desplegable
- **Mensajes motivacionales**: Frases inspiradoras para traders
- **Gráfico de progreso interactivo**: Visualización del rendimiento usando Recharts
- **Cards de acciones rápidas**: Botones para acceder a las funcionalidades principales
- **Resumen de datos**: Mostrar información clave del día actual

### 3. Registro del Día
- **Entrada de saldo real**: Campo para ingresar el saldo exacto al cierre
- **Cálculos automáticos**: Profit total, profit para retiro, profit de acumulación
- **Consejo psicológico**: Tip sobre cómo registrar pérdidas vs ganancias
- **Sistema de evaluación**: Clasificación del rendimiento (éxito/advertencia/peligro)
- **Control de retiros**: Registro detallado de retiros con tipo (profit/balance total)
- **Mensajes motivacionales**: Feedback según el rendimiento del día
- **Validaciones**: Verificar que los datos ingresados sean correctos

### 4. Calculadora de Riesgo
- **Cálculo de tamaño de lote**: Basado en capital y porcentaje de riesgo
- **Diferentes tipos de cálculo**: Por porcentaje, por monto fijo, etc.
- **Validación de inputs**: Verificar que los valores sean lógicos
- **Resultados en tiempo real**: Actualización automática al cambiar valores
- **Historial de cálculos**: Guardar cálculos anteriores para referencia

### 5. Plan Setup (Configuración)
- **Capital inicial**: Definir el monto base para trading
- **Meta de profit diario**: Configurar objetivo en porcentaje
- **Distribución de ganancias**: Porcentaje para retiro vs acumulación
- **Validación de plan**: Verificar que la configuración sea coherente
- **Persistencia**: Guardar configuración en localStorage

### 6. Integraciones
- **Plugin MT5**: Gestión completa de integración con MetaTrader 5
- **Descarga ZIP**: Botón para descargar el plugin
- **API Key**: Generación y gestión de claves de API
- **Pasos de instalación**: Guía detallada paso a paso
- **Estado de conexión**: Indicador visual del estado de la integración
- **Operaciones en vivo**: Mostrar trades solo cuando MT5 está conectado

## Estructura de Componentes

### Componentes Principales
1. **App.tsx**: Componente raíz con manejo de rutas y estados globales
2. **Dashboard.tsx**: Pantalla principal con navegación y resumen
3. **DayRegister.tsx**: Formulario de registro diario con cálculos
4. **RiskCalculator.tsx**: Calculadora de gestión de riesgo
5. **PlanSetup.tsx**: Configuración del plan de trading
6. **Integrations.tsx**: Gestión de integraciones y conexiones
7. **Login.tsx**: Pantalla de autenticación con OAuth
8. **UserMenu.tsx**: Menú desplegable del usuario

### Componentes de Utilidad
1. **SummaryCards.tsx**: Cards de resumen en el dashboard
2. **TradingOperations.tsx**: Visualización de operaciones de trading
3. **ImageWithFallback.tsx**: Componente protegido para imágenes

### Utilidades (utils/)
1. **auth-utils.ts**: Manejo de autenticación y sesiones
2. **plan-utils.ts**: Gestión de configuración del plan
3. **integration-utils.ts**: Manejo de integraciones MT5
4. **withdrawal-utils.ts**: Gestión de retiros y transacciones
5. **risk-calculator-utils.ts**: Cálculos de riesgo y lotes
6. **chart-utils.ts**: Utilidades para gráficos y visualizaciones

## Características Técnicas Específicas

### Tecnologías
- **React 18** con TypeScript
- **Tailwind CSS v4** para estilos
- **Recharts** para gráficos interactivos
- **Lucide React** para iconografía
- **ShadCN UI** para componentes base
- **LocalStorage** para persistencia de datos

### Sistema de Navegación
- **Estados de pantalla**: Manejo por estados en lugar de router
- **Navegación fluida**: Transiciones suaves entre secciones
- **Estado persistente**: Mantener datos entre navegaciones

### Gestión de Datos
- **localStorage**: Para configuraciones, sesión y datos históricos
- **Estados locales**: Para datos temporales y formularios
- **Validaciones**: Verificación de datos en tiempo real
- **Formato chileno**: Números y fechas en formato local

### Responsive Design
- **Mobile-first**: Diseño optimizado para móviles
- **Grid adaptativo**: Layouts que se ajustan a diferentes pantallas
- **Componentes flexibles**: UI que funciona en desktop y móvil
- **Touch-friendly**: Elementos fáciles de usar en pantallas táctiles

## Flujo de Usuario Específico

### Primera Vez
1. **Login**: Autenticación con OAuth (Google/Apple/Facebook)
2. **Plan Setup**: Configuración obligatoria del plan de trading
3. **Dashboard**: Acceso a la pantalla principal
4. **Exploración**: Usuario puede explorar todas las funcionalidades

### Uso Diario
1. **Login automático**: Si tiene sesión guardada
2. **Dashboard**: Ver resumen del día y progreso
3. **Registro del día**: Ingresar resultados de trading
4. **Calculadora**: Usar para planificar próximas operaciones

### Integración MT5
1. **Configuración**: Acceder a sección Integraciones
2. **Descarga**: Descargar plugin ZIP
3. **Instalación**: Seguir pasos detallados
4. **Conexión**: Verificar estado y activar integración
5. **Operaciones**: Ver trades en vivo (solo con MT5 activo)

## Reglas de Negocio Importantes

### Cálculos Financieros
- **Profit total** = Saldo real - Saldo inicial
- **Profit retiro** = Profit total × Porcentaje retiro (ej: 70%)
- **Profit acumulación** = Profit total × Porcentaje acumulación (ej: 30%)
- **Meta alcanzada** = (Profit total / Meta diaria) × 100

### Evaluación de Rendimiento
- **Éxito**: ≥95% de la meta diaria
- **Advertencia**: 70%-94% de la meta diaria  
- **Peligro**: <70% de la meta diaria

### Control de Retiros
- **Tipos**: Solo profit vs Balance total
- **Validaciones**: No exceder montos disponibles
- **Registro**: Fecha, monto, tipo y notas opcionales
- **Historial**: Mantener registro de todos los retiros

### Consejo Psicológico
- **Pérdidas**: Registrar cifras aproximadas para reducir impacto emocional
- **Ganancias**: Registrar solo ganancias para mantener mentalidad positiva
- **Motivación**: Mensajes diferentes según el rendimiento

### Integración MT5
- **Operaciones**: Solo mostrar cuando MT5 está conectado
- **Sin conexión**: Mostrar solo resúmenes manuales del registro diario
- **Estados**: Desconectado, Conectando, Conectado, Error
- **Plugin**: Descarga, instalación y configuración paso a paso

## Estilo y UX Específicos

### Principios de Diseño
- **Minimalista**: Interfaz limpia sin elementos innecesarios
- **Profesional**: Aspecto serio y confiable para traders
- **Moderno**: Uso de elementos visuales contemporáneos
- **Enfoque en la acción**: Botones y acciones claramente visibles

### Tipografía
- **Base**: 14px para texto general
- **Jerarquía**: Tamaños progresivos para títulos (h1-h4)
- **Pesos**: Medium (500) para títulos, Normal (400) para texto
- **Legibilidad**: Alto contraste y espaciado adecuado

### Componentes UI
- **Cards**: Para agrupar información relacionada
- **Alerts**: Para mensajes importantes y feedback
- **Badges**: Para estados y categorías
- **Buttons**: Diferenciación clara entre primarios y secundarios
- **Forms**: Validación visual y mensajes de error claros

### Interacciones
- **Hover states**: Feedback visual en elementos interactivos
- **Loading states**: Indicadores de carga para operaciones async
- **Animations**: Transiciones suaves pero no distractoras
- **Feedback**: Confirmaciones claras para acciones importantes

## Archivos de Configuración

### globals.css
- Variables CSS para colores del tema
- Tipografía base responsive
- Estilos específicos para inputs (color negro para texto)
- Configuración de Tailwind v4

### Constantes
- URLs de descarga de plugins
- Mensajes motivacionales
- Configuraciones por defecto
- Textos de la aplicación

## Consideraciones de Desarrollo

### Estados de la Aplicación
- **Loading**: Durante verificación de sesión
- **No autenticado**: Mostrar login
- **Plan no configurado**: Redirigir a setup
- **Funcionamiento normal**: Acceso completo

### Manejo de Errores
- **Validación de forms**: Mensajes claros y específicos
- **Errores de conexión**: Fallbacks apropiados
- **Datos faltantes**: Estados de placeholder informativos

### Performance
- **Component memoization**: Para componentes pesados
- **Lazy loading**: Para secciones no críticas
- **LocalStorage management**: Limpieza de datos antiguos

### Accesibilidad
- **Keyboard navigation**: Navegación completa por teclado
- **Screen readers**: Labels y descriptions apropiados
- **Color contrast**: Cumplir estándares WCAG
- **Focus management**: Estados de foco claros

Este prompt completo sirve como documentación técnica y funcional para recrear o continuar el desarrollo de Trading Planner con todas sus características específicas implementadas.