// Mensajes motivacionales para el dashboard
export const motivationalMessages = [
  "⚠️ Recuerda: no arriesgues más del 1% por operación",
  "💪 La disciplina es tu mayor ganancia",
  "🎯 Mantén tu plan, los resultados seguirán",
  "⏰ El mercado estará ahí mañana, tu capital no siempre",
  "📈 Operaciones pequeñas y consistentes generan grandes resultados"
];

// Datos de demostración para login
export const demoUsers = [
  { email: 'demo@tradingplanner.cl', password: 'demo123', name: 'Usuario Demo' },
  { email: 'trader@example.com', password: 'trader2024', name: 'Trader Pro' }
];

// Función para obtener datos de resumen basados en el plan configurado
export const getSummaryData = () => {
  // Importar aquí para evitar dependencias circulares
  const getSavedPlan = () => {
    const savedPlan = localStorage.getItem('tradingPlan');
    if (savedPlan) {
      try {
        return JSON.parse(savedPlan);
      } catch (error) {
        return null;
      }
    }
    return null;
  };

  const plan = getSavedPlan();
  
  if (plan) {
    const metaDia = (plan.capitalInicial * plan.metaDiariaPercent) / 100;
    return {
      saldoInicial: plan.capitalInicial,
      metaDia: metaDia,
      avancePlan: { porcentaje: 78.4, monto: metaDia * 0.784 },
      riesgoOperacion: { porcentaje: 1.0, monto: plan.capitalInicial * 0.01 },
      riesgoTotal: { porcentaje: 3.0, monto: plan.capitalInicial * 0.03 },
      profitDiario: metaDia,
      profitAcumulado: metaDia * 18 // Simular 18 días de trading exitoso
    };
  }

  // Datos por defecto si no hay plan configurado
  return {
    saldoInicial: 15750.00,
    metaDia: 157.50,
    avancePlan: { porcentaje: 78.4, monto: 123.45 },
    riesgoOperacion: { porcentaje: 1.0, monto: 157.50 },
    riesgoTotal: { porcentaje: 3.0, monto: 472.50 },
    profitDiario: 157.50,
    profitAcumulado: 2835.60
  };
};

// Configuración de instrumentos para calculadora de riesgo
export const instrumentos = {
  'EURUSD': { pipValue: 10, digits: 5, contractSize: 100000 },
  'GBPUSD': { pipValue: 10, digits: 5, contractSize: 100000 },
  'USDJPY': { pipValue: 9.09, digits: 3, contractSize: 100000 },
  'XAUUSD': { pipValue: 1, digits: 2, contractSize: 100 },
  'BTCUSDT': { pipValue: 0.1, digits: 2, contractSize: 1 },
  'US30': { pipValue: 1, digits: 1, contractSize: 1 }
};

// Función para obtener plan de riesgo basado en la configuración
export const getPlanRiesgo = () => {
  const getSavedPlan = () => {
    const savedPlan = localStorage.getItem('tradingPlan');
    if (savedPlan) {
      try {
        return JSON.parse(savedPlan);
      } catch (error) {
        return null;
      }
    }
    return null;
  };

  const plan = getSavedPlan();
  
  if (plan) {
    return {
      riesgoPorOperacion: { porcentaje: 1.0, monto: plan.capitalInicial * 0.01 },
      perdidaDiariaMaxima: { porcentaje: 3.0, monto: plan.capitalInicial * 0.03 },
      maxTradesDia: 3
    };
  }

  // Plan por defecto
  return {
    riesgoPorOperacion: { porcentaje: 1.0, monto: 157.50 },
    perdidaDiariaMaxima: { porcentaje: 3.0, monto: 472.50 },
    maxTradesDia: 3
  };
};