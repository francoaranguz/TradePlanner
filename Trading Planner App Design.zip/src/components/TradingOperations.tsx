import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from './ui/table';
import { 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  Target, 
  Calendar,
  DollarSign,
  Percent,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  ExternalLink
} from 'lucide-react';
import { 
  getMockTradingOperations, 
  calculateTradingKPIs, 
  TradingKPIs, 
  TradingOperation 
} from './utils/integration-utils';

interface TradingOperationsProps {
  onNavigateToIntegrations: () => void;
}

export function TradingOperations({ onNavigateToIntegrations }: TradingOperationsProps) {
  const [operations, setOperations] = useState<TradingOperation[]>([]);
  const [kpis, setKpis] = useState<TradingKPIs | null>(null);
  const [showAllOperations, setShowAllOperations] = useState(false);

  useEffect(() => {
    // Cargar operaciones mock
    const mockOperations = getMockTradingOperations();
    setOperations(mockOperations);
    
    // Calcular KPIs
    const calculatedKPIs = calculateTradingKPIs(mockOperations);
    setKpis(calculatedKPIs);
  }, []);

  const displayedOperations = showAllOperations ? operations : operations.slice(0, 5);

  const getOperationIcon = (tipo: 'BUY' | 'SELL', estado: string) => {
    if (estado === 'GANADA') {
      return tipo === 'BUY' ? 
        <ArrowUpRight className="w-4 h-4 text-success" /> : 
        <ArrowDownRight className="w-4 h-4 text-success" />;
    } else if (estado === 'PERDIDA') {
      return tipo === 'BUY' ? 
        <ArrowUpRight className="w-4 h-4 text-destructive" /> : 
        <ArrowDownRight className="w-4 h-4 text-destructive" />;
    } else {
      return <Minus className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'GANADA':
        return <Badge className="bg-success text-success-foreground">Ganada</Badge>;
      case 'PERDIDA':
        return <Badge variant="destructive">Perdida</Badge>;
      case 'BREAK_EVEN':
        return <Badge variant="secondary">Break Even</Badge>;
      default:
        return <Badge variant="outline">{estado}</Badge>;
    }
  };

  if (!kpis) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="bg-card/50">
              <CardContent className="p-4">
                <div className="h-4 bg-muted animate-pulse rounded mb-2"></div>
                <div className="h-6 bg-muted animate-pulse rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-primary" />
              <p className="text-sm text-muted-foreground">Win Rate</p>
            </div>
            <p className="text-xl font-bold text-primary">
              {kpis.winRate.toFixed(1)}%
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <BarChart3 className="w-4 h-4 text-success" />
              <p className="text-sm text-muted-foreground">Profit Factor</p>
            </div>
            <p className="text-xl font-bold text-success">
              {kpis.profitFactor === 999 ? '∞' : kpis.profitFactor.toFixed(2)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-primary" />
              <p className="text-sm text-muted-foreground">Expectancy</p>
            </div>
            <p className={`text-xl font-bold ${kpis.expectancy >= 0 ? 'text-success' : 'text-destructive'}`}>
              ${kpis.expectancy.toFixed(2)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Percent className="w-4 h-4 text-primary" />
              <p className="text-sm text-muted-foreground">Avg R</p>
            </div>
            <p className={`text-xl font-bold ${kpis.avgR >= 0 ? 'text-success' : 'text-destructive'}`}>
              {kpis.avgR.toFixed(2)}R
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-primary" />
              <p className="text-sm text-muted-foreground">Nº Trades</p>
            </div>
            <p className="text-xl font-bold text-foreground">
              {kpis.totalTrades}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabla de operaciones */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-primary" />
              Operaciones Recientes
            </CardTitle>
            <Button 
              onClick={onNavigateToIntegrations}
              variant="outline"
              size="sm"
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Ver Integraciones
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {operations.length === 0 ? (
            <div className="text-center py-8 space-y-4">
              <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto" />
              <div>
                <p className="text-muted-foreground mb-2">No hay operaciones registradas</p>
                <p className="text-sm text-muted-foreground">
                  Conecta el plugin MT5 para ver tus operaciones automáticamente
                </p>
              </div>
              <Button 
                onClick={onNavigateToIntegrations}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Configurar Integración
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Símbolo</TableHead>
                      <TableHead>Lotes</TableHead>
                      <TableHead>Entrada</TableHead>
                      <TableHead>SL/TP</TableHead>
                      <TableHead>Cierre</TableHead>
                      <TableHead className="text-right">P/L</TableHead>
                      <TableHead className="text-right">R</TableHead>
                      <TableHead>Estado</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {displayedOperations.map((operation) => (
                      <TableRow key={operation.id}>
                        <TableCell className="font-medium">
                          {new Date(operation.fecha).toLocaleDateString('es-CL')}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getOperationIcon(operation.tipo, operation.estado)}
                            <span>{operation.simbolo}</span>
                          </div>
                        </TableCell>
                        <TableCell>{operation.lotes}</TableCell>
                        <TableCell>{operation.entrada.toFixed(operation.simbolo.includes('JPY') ? 3 : 5)}</TableCell>
                        <TableCell>
                          <div className="text-xs space-y-1">
                            <div>SL: {operation.sl.toFixed(operation.simbolo.includes('JPY') ? 3 : 5)}</div>
                            <div>TP: {operation.tp.toFixed(operation.simbolo.includes('JPY') ? 3 : 5)}</div>
                          </div>
                        </TableCell>
                        <TableCell>{operation.cierre.toFixed(operation.simbolo.includes('JPY') ? 3 : 5)}</TableCell>
                        <TableCell className={`text-right font-medium ${
                          operation.pl > 0 ? 'text-success' : 
                          operation.pl < 0 ? 'text-destructive' : 
                          'text-muted-foreground'
                        }`}>
                          {operation.pl > 0 ? '+' : ''}${operation.pl.toFixed(2)}
                        </TableCell>
                        <TableCell className={`text-right font-medium ${
                          operation.r > 0 ? 'text-success' : 
                          operation.r < 0 ? 'text-destructive' : 
                          'text-muted-foreground'
                        }`}>
                          {operation.r > 0 ? '+' : ''}{operation.r.toFixed(1)}R
                        </TableCell>
                        <TableCell>
                          {getEstadoBadge(operation.estado)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {operations.length > 5 && (
                <div className="text-center">
                  <Button 
                    onClick={() => setShowAllOperations(!showAllOperations)}
                    variant="outline"
                    size="sm"
                  >
                    {showAllOperations ? 'Ver menos' : `Ver todas (${operations.length})`}
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resumen adicional */}
      {kpis.totalTrades > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-success/5 border-success/30">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-success" />
                <p className="text-sm text-success">Operaciones Ganadoras</p>
              </div>
              <p className="text-xl font-bold text-success">
                {kpis.winningTrades} (${kpis.totalProfit.toFixed(2)})
              </p>
            </CardContent>
          </Card>

          <Card className="bg-destructive/5 border-destructive/30">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="w-4 h-4 text-destructive" />
                <p className="text-sm text-destructive">Operaciones Perdedoras</p>
              </div>
              <p className="text-xl font-bold text-destructive">
                {kpis.losingTrades} (-${kpis.totalLoss.toFixed(2)})
              </p>
            </CardContent>
          </Card>

          <Card className="bg-primary/5 border-primary/30">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-4 h-4 text-primary" />
                <p className="text-sm text-primary">Profit Neto</p>
              </div>
              <p className={`text-xl font-bold ${
                (kpis.totalProfit - kpis.totalLoss) >= 0 ? 'text-success' : 'text-destructive'
              }`}>
                ${(kpis.totalProfit - kpis.totalLoss).toFixed(2)}
              </p>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}