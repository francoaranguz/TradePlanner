import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Separator } from './ui/separator';
import { ArrowLeft, Calculator, Shield, AlertTriangle, TrendingDown, Target, Clock } from 'lucide-react';
import { getPlanRiesgo } from './constants/app-constants';
import { calculateRiskResults, getRiskAlerts } from './utils/risk-calculator-utils';

interface User {
  email: string;
  name: string;
}

interface RiskCalculatorProps {
  onBack: () => void;
  user: User | null;
}

export function RiskCalculator({ onBack, user }: RiskCalculatorProps) {
  const [capital, setCapital] = useState<string>('15750');
  const [riesgoPercent, setRiesgoPercent] = useState<string>('1.0');
  const [instrumento, setInstrumento] = useState<string>('EURUSD');
  const [precioEntrada, setPrecioEntrada] = useState<string>('');
  const [stopLoss, setStopLoss] = useState<string>('');

  const [results, setResults] = useState({
    tamanoLote: 0,
    margenEstimado: 0,
    perdidaPotencial: 0,
    pipsStop: 0
  });

  useEffect(() => {
    const calculatedResults = calculateRiskResults(capital, riesgoPercent, instrumento, precioEntrada, stopLoss);
    setResults(calculatedResults);
  }, [capital, riesgoPercent, instrumento, precioEntrada, stopLoss]);

  const planRiesgo = getPlanRiesgo();
  const riskAlerts = getRiskAlerts(
    parseFloat(riesgoPercent),
    results.perdidaPotencial,
    results.margenEstimado,
    parseFloat(capital),
    planRiesgo.riesgoPorOperacion.monto
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-muted p-4">
        <div className="max-w-6xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            onClick={onBack}
            className="text-primary hover:text-primary/80"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-primary">Calculadora de Riesgo</h1>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6 space-y-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Calculadora principal */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-primary" />
                  Parámetros de Trading
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Capital */}
                  <div className="space-y-2">
                    <Label htmlFor="capital" className="text-primary font-medium">
                      Capital Disponible ($)
                    </Label>
                    <Input
                      id="capital"
                      type="number"
                      step="0.01"
                      value={capital}
                      onChange={(e) => setCapital(e.target.value)}
                      className="font-mono border-primary/30 focus:border-primary"
                    />
                  </div>

                  {/* Riesgo porcentaje */}
                  <div className="space-y-2">
                    <Label htmlFor="riesgo" className="text-primary font-medium">
                      % Riesgo por Operación
                    </Label>
                    <Input
                      id="riesgo"
                      type="number"
                      step="0.1"
                      min="0.1"
                      max="5"
                      value={riesgoPercent}
                      onChange={(e) => setRiesgoPercent(e.target.value)}
                      className="font-mono border-primary/30 focus:border-primary"
                    />
                  </div>

                  {/* Instrumento */}
                  <div className="space-y-2">
                    <Label className="text-primary font-medium">
                      Instrumento
                    </Label>
                    <Select value={instrumento} onValueChange={setInstrumento}>
                      <SelectTrigger className="border-primary/30 focus:border-primary">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="EURUSD">EUR/USD</SelectItem>
                        <SelectItem value="GBPUSD">GBP/USD</SelectItem>
                        <SelectItem value="USDJPY">USD/JPY</SelectItem>
                        <SelectItem value="XAUUSD">XAU/USD (Oro)</SelectItem>
                        <SelectItem value="BTCUSDT">BTC/USDT</SelectItem>
                        <SelectItem value="US30">US30 (Dow Jones)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Precio de entrada */}
                  <div className="space-y-2">
                    <Label htmlFor="entrada" className="text-primary font-medium">
                      Precio de Entrada
                    </Label>
                    <Input
                      id="entrada"
                      type="number"
                      step="0.00001"
                      value={precioEntrada}
                      onChange={(e) => setPrecioEntrada(e.target.value)}
                      placeholder="Ej: 1.10250"
                      className="font-mono border-primary/30 focus:border-primary"
                    />
                  </div>

                  {/* Stop Loss */}
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="stop" className="text-primary font-medium">
                      Stop Loss
                    </Label>
                    <Input
                      id="stop"
                      type="number"
                      step="0.00001"
                      value={stopLoss}
                      onChange={(e) => setStopLoss(e.target.value)}
                      placeholder="Ej: 1.10150"
                      className="font-mono border-primary/30 focus:border-primary"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Resultados */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-success" />
                  Resultados del Cálculo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="p-4 bg-success/10 border border-success/30 rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">Tamaño de Lote/Cantidad</p>
                      <p className="text-2xl font-bold text-success font-mono">
                        {results.tamanoLote.toFixed(2)}
                      </p>
                    </div>

                    <div className="p-4 bg-primary/10 border border-primary/30 rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">Pips hasta Stop Loss</p>
                      <p className="text-xl font-bold text-primary font-mono">
                        {results.pipsStop.toFixed(1)} pips
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-muted/30 border border-muted rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">Margen Estimado ($)</p>
                      <p className="text-xl font-bold font-mono">
                        ${results.margenEstimado.toLocaleString('es-CL')}
                      </p>
                    </div>

                    <div className="p-4 bg-destructive/10 border border-destructive/30 rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">Pérdida Potencial ($)</p>
                      <p className="text-xl font-bold text-destructive font-mono">
                        ${results.perdidaPotencial.toLocaleString('es-CL')}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Plan de riesgo fijo */}
          <div className="space-y-6">
            <Card className="bg-muted/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-primary" />
                  Plan de Riesgo
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Riesgo por Operación</span>
                    <div className="text-right">
                      <p className="font-bold text-destructive">
                        {planRiesgo.riesgoPorOperacion.porcentaje}%
                      </p>
                      <p className="text-sm text-muted-foreground">
                        ${planRiesgo.riesgoPorOperacion.monto.toLocaleString('es-CL')}
                      </p>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Pérdida Diaria Máxima</span>
                    <div className="text-right">
                      <p className="font-bold text-destructive">
                        {planRiesgo.perdidaDiariaMaxima.porcentaje}%
                      </p>
                      <p className="text-sm text-muted-foreground">
                        ${planRiesgo.perdidaDiariaMaxima.monto.toLocaleString('es-CL')}
                      </p>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Máximo Trades/Día</span>
                    <div className="text-right">
                      <p className="font-bold text-primary">
                        {planRiesgo.maxTradesDia}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Alertas de riesgo */}
            <Card className="bg-destructive/5 border-destructive/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-destructive">
                  <AlertTriangle className="w-5 h-5" />
                  Alertas de Riesgo
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {riskAlerts.map((alert, index) => (
                  <div key={index} className="flex items-start gap-2 p-3 bg-destructive/10 rounded-lg">
                    <TrendingDown className="w-4 h-4 text-destructive mt-0.5" />
                    <p className="text-sm text-destructive">
                      {alert.message}
                    </p>
                  </div>
                ))}
                {riskAlerts.length === 0 && (
                  <div className="flex items-start gap-2 p-3 bg-success/10 rounded-lg">
                    <Target className="w-4 h-4 text-success mt-0.5" />
                    <p className="text-sm text-success">
                      ✅ Parámetros de riesgo dentro del plan
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Estado del día */}
            <Card className="bg-primary/5 border-primary/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <Clock className="w-5 h-5" />
                  Estado del Día
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Trades Realizados</span>
                  <span className="font-bold text-primary">0 / {planRiesgo.maxTradesDia}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Pérdida Acumulada</span>
                  <span className="font-bold text-success">$0.00</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Riesgo Restante</span>
                  <span className="font-bold text-primary">
                    ${planRiesgo.perdidaDiariaMaxima.monto.toLocaleString('es-CL')}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Mensaje motivacional fijo */}
        <Card className="bg-gradient-to-r from-primary/20 to-primary/10 border-primary/30">
          <CardContent className="p-6 text-center">
            <p className="text-xl font-bold text-primary">
              💪 La disciplina es tu mayor ganancia
            </p>
            <p className="text-muted-foreground mt-2">
              Respeta siempre tu plan de riesgo y mantén la consistencia en tus operaciones
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}