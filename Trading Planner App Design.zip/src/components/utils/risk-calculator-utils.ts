import { instrumentos } from '../constants/app-constants';

export interface RiskCalculationResult {
  tamanoLote: number;
  margenEstimado: number;
  perdidaPotencial: number;
  pipsStop: number;
}

// Función para calcular los resultados de riesgo
export const calculateRiskResults = (
  capital: string,
  riesgoPercent: string,
  instrumento: string,
  precioEntrada: string,
  stopLoss: string
): RiskCalculationResult => {
  const capitalNum = parseFloat(capital);
  const riesgoPercentNum = parseFloat(riesgoPercent);
  const precioEntradaNum = parseFloat(precioEntrada);
  const stopLossNum = parseFloat(stopLoss);

  if (!capitalNum || !riesgoPercentNum || !precioEntradaNum || !stopLossNum) {
    return { tamanoLote: 0, margenEstimado: 0, perdidaPotencial: 0, pipsStop: 0 };
  }

  const instrumentData = instrumentos[instrumento as keyof typeof instrumentos];
  if (!instrumentData) {
    return { tamanoLote: 0, margenEstimado: 0, perdidaPotencial: 0, pipsStop: 0 };
  }

  // Calcular diferencia en pips
  const diferenciaPrecio = Math.abs(precioEntradaNum - stopLossNum);
  const pipsStop = diferenciaPrecio * Math.pow(10, instrumentData.digits);

  // Calcular riesgo en dinero
  const riesgoMonto = (capitalNum * riesgoPercentNum) / 100;

  // Calcular tamaño de lote
  const pipValuePerLote = instrumentData.pipValue;
  const tamanoLote = riesgoMonto / (pipsStop * pipValuePerLote);

  // Calcular margen estimado (aproximado - varía según broker)
  const apalancamiento = instrumento.includes('USD') ? 100 : 50; // Aproximación
  const margenEstimado = (tamanoLote * instrumentData.contractSize * precioEntradaNum) / apalancamiento;

  // Pérdida potencial
  const perdidaPotencial = riesgoMonto;

  return {
    tamanoLote,
    margenEstimado,
    perdidaPotencial,
    pipsStop
  };
};

// Función para validar alertas de riesgo
export const getRiskAlerts = (
  riesgoPercent: number,
  perdidaPotencial: number,
  margenEstimado: number,
  capital: number,
  planRiesgoMonto: number
): Array<{ message: string }> => {
  const alerts = [];

  if (riesgoPercent > 2) {
    alerts.push({
      message: '⚠️ Riesgo superior al 2% por operación'
    });
  }

  if (perdidaPotencial > planRiesgoMonto) {
    alerts.push({
      message: '⚠️ Pérdida potencial excede el plan de riesgo'
    });
  }

  if (margenEstimado > capital * 0.5) {
    alerts.push({
      message: '⚠️ Margen muy alto (>50% del capital)'
    });
  }

  return alerts;
};