// Función para generar datos mock del gráfico según la vista seleccionada
export const generateMockData = (view: string) => {
  const now = new Date();
  const data = [];
  
  if (view === 'daily') {
    // Datos diarios del mes actual
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    for (let i = 1; i <= daysInMonth; i++) {
      data.push({
        period: `${i}`,
        saldo: 10000 + (Math.random() * 2000 - 1000) + (i * 50),
        meta: 10000 + (i * 100)
      });
    }
  } else if (view === 'weekly') {
    // Datos semanales de los últimos 6 meses
    for (let i = 0; i < 24; i++) {
      const weekDate = new Date(now);
      weekDate.setDate(weekDate.getDate() - (i * 7));
      data.unshift({
        period: `S${24-i}`,
        saldo: 10000 + (Math.random() * 3000 - 1500) + (i * 200),
        meta: 10000 + (i * 250)
      });
    }
  } else {
    // Datos mensuales del año actual
    const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    for (let i = 0; i < 12; i++) {
      data.push({
        period: months[i],
        saldo: 10000 + (Math.random() * 5000 - 2500) + (i * 800),
        meta: 10000 + (i * 1000)
      });
    }
  }
  
  return data;
};

// Función para exportar datos del gráfico a Excel (CSV)
export const exportChartToExcel = (chartData: any[], chartView: string) => {
  const viewName = chartView === 'daily' ? 'Diario' : chartView === 'weekly' ? 'Semanal' : 'Mensual';
  const currentDate = new Date().toLocaleDateString('es-CL');
  
  // Crear encabezados CSV
  let csvContent = `Trading Planner - Reporte ${viewName}\n`;
  csvContent += `Fecha de Exportación: ${currentDate}\n\n`;
  csvContent += `Período,Saldo Real,Meta\n`;
  
  // Agregar datos
  chartData.forEach(row => {
    csvContent += `${row.period},${row.saldo.toFixed(2)},${row.meta.toFixed(2)}\n`;
  });
  
  // Agregar resumen estadístico
  const maxSaldo = Math.max(...chartData.map(d => d.saldo));
  const minSaldo = Math.min(...chartData.map(d => d.saldo));
  const promedioSaldo = chartData.reduce((sum, d) => sum + d.saldo, 0) / chartData.length;
  const maxMeta = Math.max(...chartData.map(d => d.meta));
  const promedioMeta = chartData.reduce((sum, d) => sum + d.meta, 0) / chartData.length;
  
  csvContent += `\nResumen Estadístico\n`;
  csvContent += `Métrica,Valor\n`;
  csvContent += `Saldo Máximo,${maxSaldo.toFixed(2)}\n`;
  csvContent += `Saldo Mínimo,${minSaldo.toFixed(2)}\n`;
  csvContent += `Saldo Promedio,${promedioSaldo.toFixed(2)}\n`;
  csvContent += `Meta Máxima,${maxMeta.toFixed(2)}\n`;
  csvContent += `Meta Promedio,${promedioMeta.toFixed(2)}\n`;
  
  // Crear y descargar archivo
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', `Trading_Planner_${viewName}_${currentDate.replace(/\//g, '-')}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};