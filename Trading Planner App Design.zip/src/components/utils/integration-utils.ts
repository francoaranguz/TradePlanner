export interface ApiKey {
  key: string;
  created: string;
  lastUsed: string | null;
}

export interface TradingOperation {
  id: string;
  fecha: string;
  simbolo: string;
  lotes: number;
  entrada: number;
  sl: number;
  tp: number;
  cierre: number;
  pl: number;
  r: number;
  tipo: 'BUY' | 'SELL';
  estado: 'GANADA' | 'PERDIDA' | 'BREAK_EVEN';
}

export interface TradingKPIs {
  winRate: number;
  profitFactor: number;
  expectancy: number;
  avgR: number;
  totalTrades: number;
  totalProfit: number;
  totalLoss: number;
  winningTrades: number;
  losingTrades: number;
}

// Función para generar una nueva API Key
export const generateApiKey = (): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = 'tp_';
  for (let i = 0; i < 32; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

// Función para obtener o crear API Key
export const getOrCreateApiKey = (): ApiKey => {
  const savedKey = localStorage.getItem('tradingPlannerApiKey');
  
  if (savedKey) {
    try {
      return JSON.parse(savedKey);
    } catch (error) {
      console.error('Error loading saved API key:', error);
    }
  }

  // Crear nueva API Key
  const newKey: ApiKey = {
    key: generateApiKey(),
    created: new Date().toISOString(),
    lastUsed: null
  };

  localStorage.setItem('tradingPlannerApiKey', JSON.stringify(newKey));
  return newKey;
};

// Función para regenerar API Key
export const regenerateApiKey = (): ApiKey => {
  const newKey: ApiKey = {
    key: generateApiKey(),
    created: new Date().toISOString(),
    lastUsed: null
  };

  localStorage.setItem('tradingPlannerApiKey', JSON.stringify(newKey));
  return newKey;
};

// Función para copiar al portapapeles
export const copyToClipboard = async (text: string): Promise<boolean> => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    // Fallback para navegadores que no soportan clipboard API
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
      document.execCommand('copy');
      document.body.removeChild(textArea);
      return true;
    } catch (err) {
      document.body.removeChild(textArea);
      return false;
    }
  }
};

// Función para obtener datos mock de operaciones
export const getMockTradingOperations = (): TradingOperation[] => {
  return [
    {
      id: '1',
      fecha: '2024-12-28',
      simbolo: 'EURUSD',
      lotes: 0.1,
      entrada: 1.05420,
      sl: 1.05320,
      tp: 1.05620,
      cierre: 1.05520,
      pl: 100.00,
      r: 1.0,
      tipo: 'BUY',
      estado: 'GANADA'
    },
    {
      id: '2',
      fecha: '2024-12-27',
      simbolo: 'GBPUSD',
      lotes: 0.15,
      entrada: 1.26800,
      sl: 1.26900,
      tp: 1.26600,
      cierre: 1.26700,
      pl: 150.00,
      r: 1.0,
      tipo: 'SELL',
      estado: 'GANADA'
    },
    {
      id: '3',
      fecha: '2024-12-27',
      simbolo: 'USDJPY',
      lotes: 0.1,
      entrada: 157.420,
      sl: 157.320,
      tp: 157.620,
      cierre: 157.320,
      pl: -91.00,
      r: -1.0,
      tipo: 'BUY',
      estado: 'PERDIDA'
    },
    {
      id: '4',
      fecha: '2024-12-26',
      simbolo: 'XAUUSD',
      lotes: 0.05,
      entrada: 2658.50,
      sl: 2650.00,
      tp: 2675.00,
      cierre: 2670.20,
      pl: 58.50,
      r: 1.38,
      tipo: 'BUY',
      estado: 'GANADA'
    },
    {
      id: '5',
      fecha: '2024-12-26',
      simbolo: 'EURUSD',
      lotes: 0.12,
      entrada: 1.05220,
      sl: 1.05120,
      tp: 1.05420,
      cierre: 1.05220,
      pl: 0.00,
      r: 0.0,
      tipo: 'BUY',
      estado: 'BREAK_EVEN'
    }
  ];
};

// Función para calcular KPIs de trading
export const calculateTradingKPIs = (operations: TradingOperation[]): TradingKPIs => {
  if (operations.length === 0) {
    return {
      winRate: 0,
      profitFactor: 0,
      expectancy: 0,
      avgR: 0,
      totalTrades: 0,
      totalProfit: 0,
      totalLoss: 0,
      winningTrades: 0,
      losingTrades: 0
    };
  }

  const winningOps = operations.filter(op => op.pl > 0);
  const losingOps = operations.filter(op => op.pl < 0);
  
  const totalProfit = winningOps.reduce((sum, op) => sum + op.pl, 0);
  const totalLoss = Math.abs(losingOps.reduce((sum, op) => sum + op.pl, 0));
  
  const winRate = (winningOps.length / operations.length) * 100;
  const profitFactor = totalLoss > 0 ? totalProfit / totalLoss : totalProfit > 0 ? 999 : 0;
  
  const totalPL = operations.reduce((sum, op) => sum + op.pl, 0);
  const expectancy = totalPL / operations.length;
  
  const avgR = operations.reduce((sum, op) => sum + op.r, 0) / operations.length;

  return {
    winRate,
    profitFactor,
    expectancy,
    avgR,
    totalTrades: operations.length,
    totalProfit,
    totalLoss,
    winningTrades: winningOps.length,
    losingTrades: losingOps.length
  };
};

// Función para verificar si el usuario tiene integración MT5 configurada
export const hasMT5Integration = (): boolean => {
  const apiKey = localStorage.getItem('tradingPlannerApiKey');
  const mt5Configured = localStorage.getItem('tradingPlannerMT5Configured');
  return !!(apiKey && mt5Configured === 'true');
};

// Función para marcar la integración MT5 como configurada
export const setMT5Integration = (configured: boolean): void => {
  localStorage.setItem('tradingPlannerMT5Configured', configured.toString());
};

// Función para simular estado de conexión
export const getConnectionStatus = (): { connected: boolean; lastUpdate: string | null } => {
  // Solo mostrar como conectado si hay integración configurada
  if (!hasMT5Integration()) {
    return { connected: false, lastUpdate: null };
  }
  
  // Simular conexión aleatoria para demo
  const connected = Math.random() > 0.3; // 70% probabilidad de estar conectado
  const lastUpdate = connected ? new Date().toISOString() : null;
  
  return { connected, lastUpdate };
};