export interface TradingPlan {
  capitalInicial: number;
  metaDiariaPercent: number;
  fechaInicio: string;
}

export interface ProjectionResult {
  periodo: string;
  capitalFinal: number;
  profitTotal: number;
  diasTradingAnuales: number;
}

// Función para calcular proyecciones de crecimiento compuesto
export const calculateProjections = (plan: TradingPlan): ProjectionResult[] => {
  const { capitalInicial, metaDiariaPercent } = plan;
  const tasaDiaria = metaDiariaPercent / 100;
  
  // Asumimos 250 días de trading por año (días hábiles aproximados)
  const diasTradingAnuales = 250;
  
  const projections: ProjectionResult[] = [];
  
  // Proyección a 1 año
  const capitalFinal1Year = capitalInicial * Math.pow(1 + tasaDiaria, diasTradingAnuales);
  const profitTotal1Year = capitalFinal1Year - capitalInicial;
  
  projections.push({
    periodo: '1 año',
    capitalFinal: capitalFinal1Year,
    profitTotal: profitTotal1Year,
    diasTradingAnuales
  });
  
  // Proyección a 2 años
  const capitalFinal2Years = capitalInicial * Math.pow(1 + tasaDiaria, diasTradingAnuales * 2);
  const profitTotal2Years = capitalFinal2Years - capitalInicial;
  
  projections.push({
    periodo: '2 años',
    capitalFinal: capitalFinal2Years,
    profitTotal: profitTotal2Years,
    diasTradingAnuales: diasTradingAnuales * 2
  });
  
  // Proyección a 3 años
  const capitalFinal3Years = capitalInicial * Math.pow(1 + tasaDiaria, diasTradingAnuales * 3);
  const profitTotal3Years = capitalFinal3Years - capitalInicial;
  
  projections.push({
    periodo: '3 años',
    capitalFinal: capitalFinal3Years,
    profitTotal: profitTotal3Years,
    diasTradingAnuales: diasTradingAnuales * 3
  });
  
  return projections;
};

// Función para obtener el plan guardado
export const getSavedPlan = (): TradingPlan | null => {
  const savedPlan = localStorage.getItem('tradingPlan');
  if (savedPlan) {
    try {
      return JSON.parse(savedPlan);
    } catch (error) {
      console.error('Error loading saved plan:', error);
      localStorage.removeItem('tradingPlan');
    }
  }
  return null;
};

// Función para guardar el plan
export const savePlan = (plan: TradingPlan): void => {
  localStorage.setItem('tradingPlan', JSON.stringify(plan));
};

// Función para generar mensaje motivacional con proyecciones
export const generateProjectionMessage = (plan: TradingPlan): string => {
  const projections = calculateProjections(plan);
  const projection1Year = projections[0];
  
  if (projection1Year.capitalFinal > 1000000) {
    return `🚀 ¡Sigue así! En 1 año tendrías $${projection1Year.capitalFinal.toLocaleString('es-CL', { maximumFractionDigits: 0 })} USD de balance y $${projection1Year.profitTotal.toLocaleString('es-CL', { maximumFractionDigits: 0 })} USD de profit total`;
  } else {
    return `💪 ¡Mantén la disciplina! En 1 año tendrías $${projection1Year.capitalFinal.toLocaleString('es-CL')} USD de balance con $${projection1Year.profitTotal.toLocaleString('es-CL')} USD de profit`;
  }
};

// Función para validar si el plan está configurado
export const isPlanConfigured = (): boolean => {
  const plan = getSavedPlan();
  return plan !== null && plan.capitalInicial > 0 && plan.metaDiariaPercent > 0;
};

// Función para calcular la meta diaria en dinero
export const calculateDailyGoalAmount = (plan: TradingPlan, currentBalance?: number): number => {
  const balance = currentBalance || plan.capitalInicial;
  return (balance * plan.metaDiariaPercent) / 100;
};