import { demoUsers } from '../constants/app-constants';

export interface User {
  email: string;
  name: string;
  provider?: 'email' | 'google';
  avatar?: string;
}

export interface AuthResult {
  success: boolean;
  user?: User;
  message: string;
}

// Función para autenticar usuario con credenciales demo
export const authenticateUser = async (email: string, password: string): Promise<AuthResult> => {
  // Simular delay de autenticación
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const user = demoUsers.find(u => u.email === email && u.password === password);
  
  if (user) {
    const userData = { email: user.email, name: user.name };
    localStorage.setItem('tradingPlannerUser', JSON.stringify(userData));
    return {
      success: true,
      user: userData,
      message: `¡Bienvenido de vuelta, ${user.name}!`
    };
  } else {
    return {
      success: false,
      message: 'Email o contraseña incorrectos. Usa las credenciales demo.'
    };
  }
};

// Función para registrar nuevo usuario
export const registerUser = async (email: string, password: string, name: string): Promise<AuthResult> => {
  // Simular delay de registro
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  if (!name.trim()) {
    return {
      success: false,
      message: 'El nombre es requerido para registrarse'
    };
  }

  if (password.length < 6) {
    return {
      success: false,
      message: 'La contraseña debe tener al menos 6 caracteres'
    };
  }

  // Simular registro exitoso
  const userData = { email, name };
  localStorage.setItem('tradingPlannerUser', JSON.stringify(userData));
  return {
    success: true,
    user: userData,
    message: '¡Cuenta creada exitosamente! Bienvenido a Trading Planner.'
  };
};

// Función para obtener usuario guardado del localStorage
export const getSavedUser = (): User | null => {
  const savedUser = localStorage.getItem('tradingPlannerUser');
  if (savedUser) {
    try {
      return JSON.parse(savedUser);
    } catch (error) {
      console.error('Error loading saved user:', error);
      localStorage.removeItem('tradingPlannerUser');
    }
  }
  return null;
};

// Función para cerrar sesión
export const logoutUser = (): void => {
  localStorage.removeItem('tradingPlannerUser');
};

// Función de OAuth simulada para Google (en producción se conectaría con API real)
export const signInWithGoogle = async (): Promise<AuthResult> => {
  // Simular llamada a Google OAuth
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  const userData: User = {
    email: 'usuario@gmail.com',
    name: 'Usuario Google',
    provider: 'google',
    avatar: 'https://lh3.googleusercontent.com/a/default-user'
  };
  
  localStorage.setItem('tradingPlannerUser', JSON.stringify(userData));
  
  return {
    success: true,
    user: userData,
    message: '¡Bienvenido! Has iniciado sesión con Google.'
  };
};