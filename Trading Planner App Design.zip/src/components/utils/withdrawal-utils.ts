export interface WithdrawalRecord {
  id: string;
  fecha: string;
  monto: number;
  tipo: 'profit' | 'balance';
  notas?: string;
}

// Función para guardar un retiro
export const saveWithdrawal = (withdrawal: Omit<WithdrawalRecord, 'id'>): void => {
  const withdrawals = getSavedWithdrawals();
  const newWithdrawal: WithdrawalRecord = {
    ...withdrawal,
    id: Date.now().toString()
  };
  
  withdrawals.push(newWithdrawal);
  localStorage.setItem('tradingPlannerWithdrawals', JSON.stringify(withdrawals));
};

// Función para obtener todos los retiros guardados
export const getSavedWithdrawals = (): WithdrawalRecord[] => {
  try {
    const saved = localStorage.getItem('tradingPlannerWithdrawals');
    return saved ? JSON.parse(saved) : [];
  } catch (error) {
    console.error('Error loading withdrawals:', error);
    return [];
  }
};

// Función para obtener retiros de una fecha específica
export const getWithdrawalsByDate = (fecha: string): WithdrawalRecord[] => {
  const withdrawals = getSavedWithdrawals();
  return withdrawals.filter(w => w.fecha === fecha);
};

// Función para obtener el total de retiros por período
export const getWithdrawalsSummary = (startDate?: string, endDate?: string): {
  totalProfit: number;
  totalBalance: number;
  totalRetiros: number;
  count: number;
} => {
  const withdrawals = getSavedWithdrawals();
  
  let filteredWithdrawals = withdrawals;
  
  if (startDate && endDate) {
    filteredWithdrawals = withdrawals.filter(w => 
      w.fecha >= startDate && w.fecha <= endDate
    );
  }
  
  const summary = filteredWithdrawals.reduce(
    (acc, withdrawal) => {
      if (withdrawal.tipo === 'profit') {
        acc.totalProfit += withdrawal.monto;
      } else {
        acc.totalBalance += withdrawal.monto;
      }
      acc.totalRetiros += withdrawal.monto;
      acc.count += 1;
      return acc;
    },
    { totalProfit: 0, totalBalance: 0, totalRetiros: 0, count: 0 }
  );
  
  return summary;
};

// Función para eliminar un retiro
export const deleteWithdrawal = (id: string): void => {
  const withdrawals = getSavedWithdrawals();
  const updatedWithdrawals = withdrawals.filter(w => w.id !== id);
  localStorage.setItem('tradingPlannerWithdrawals', JSON.stringify(updatedWithdrawals));
};

// Función para validar monto de retiro
export const validateWithdrawal = (monto: number, tipo: 'profit' | 'balance', availableBalance?: number): {
  valid: boolean;
  message: string;
} => {
  if (monto <= 0) {
    return {
      valid: false,
      message: 'El monto debe ser mayor a 0'
    };
  }
  
  if (monto > 1000000) {
    return {
      valid: false,
      message: 'El monto no puede ser mayor a $1,000,000'
    };
  }
  
  // En producción, aquí se validaría contra el balance real disponible
  if (availableBalance && monto > availableBalance) {
    return {
      valid: false,
      message: `El monto excede tu balance disponible ($${availableBalance.toFixed(2)})`
    };
  }
  
  return {
    valid: true,
    message: 'Retiro válido'
  };
};