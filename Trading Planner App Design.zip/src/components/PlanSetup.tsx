import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { ArrowLeft, Target, DollarSign, TrendingUp, Calculator, CheckCircle, AlertCircle, Calendar } from 'lucide-react';
import { TradingPlan, savePlan, getSavedPlan, calculateProjections, calculateDailyGoalAmount } from './utils/plan-utils';

interface User {
  email: string;
  name: string;
}

interface PlanSetupProps {
  onBack: () => void;
  user: User | null;
  onPlanSaved?: () => void;
}

export function PlanSetup({ onBack, user, onPlanSaved }: PlanSetupProps) {
  const [formData, setFormData] = useState({
    capitalInicial: '',
    metaDiariaPercent: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info' | null; message: string }>({
    type: null,
    message: ''
  });
  const [projections, setProjections] = useState<any[]>([]);

  // Cargar plan existente si existe
  useEffect(() => {
    const savedPlan = getSavedPlan();
    if (savedPlan) {
      setFormData({
        capitalInicial: savedPlan.capitalInicial.toString(),
        metaDiariaPercent: savedPlan.metaDiariaPercent.toString()
      });
      calculateAndShowProjections(savedPlan);
    }
  }, []);

  const calculateAndShowProjections = (plan: TradingPlan) => {
    const projectionResults = calculateProjections(plan);
    setProjections(projectionResults);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Calcular proyecciones en tiempo real si ambos campos tienen valores
    const capitalInicial = field === 'capitalInicial' ? parseFloat(value) : parseFloat(formData.capitalInicial);
    const metaDiariaPercent = field === 'metaDiariaPercent' ? parseFloat(value) : parseFloat(formData.metaDiariaPercent);
    
    if (capitalInicial > 0 && metaDiariaPercent > 0 && metaDiariaPercent <= 10) {
      const tempPlan: TradingPlan = {
        capitalInicial,
        metaDiariaPercent,
        fechaInicio: new Date().toISOString().split('T')[0]
      };
      calculateAndShowProjections(tempPlan);
    } else {
      setProjections([]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setAlert({ type: null, message: '' });

    const capitalInicial = parseFloat(formData.capitalInicial);
    const metaDiariaPercent = parseFloat(formData.metaDiariaPercent);

    // Validaciones
    if (!capitalInicial || capitalInicial <= 0) {
      setAlert({ type: 'error', message: 'El capital inicial debe ser mayor a 0' });
      setIsLoading(false);
      return;
    }

    if (!metaDiariaPercent || metaDiariaPercent <= 0) {
      setAlert({ type: 'error', message: 'La meta diaria debe ser mayor a 0%' });
      setIsLoading(false);
      return;
    }

    if (metaDiariaPercent > 10) {
      setAlert({ type: 'error', message: 'La meta diaria no puede ser mayor al 10% (muy riesgoso)' });
      setIsLoading(false);
      return;
    }

    if (capitalInicial < 1000) {
      setAlert({ 
        type: 'info', 
        message: 'Advertencia: Capital menor a $1,000 USD puede limitar las oportunidades de trading' 
      });
    }

    // Simular guardado
    await new Promise(resolve => setTimeout(resolve, 1000));

    const newPlan: TradingPlan = {
      capitalInicial,
      metaDiariaPercent,
      fechaInicio: new Date().toISOString().split('T')[0]
    };

    savePlan(newPlan);
    setAlert({ 
      type: 'success', 
      message: '¡Plan de trading configurado exitosamente! Ya puedes ver tus proyecciones.' 
    });

    setIsLoading(false);

    // Llamar callback si existe
    if (onPlanSaved) {
      setTimeout(() => {
        onPlanSaved();
      }, 2000);
    }
  };

  const currentDailyGoal = projections.length > 0 ? 
    calculateDailyGoalAmount({
      capitalInicial: parseFloat(formData.capitalInicial),
      metaDiariaPercent: parseFloat(formData.metaDiariaPercent),
      fechaInicio: new Date().toISOString().split('T')[0]
    }) : 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-muted p-4">
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-primary"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver
          </Button>
          <div className="flex items-center gap-3">
            <Target className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-bold text-primary">Configuración del Plan</h1>
          </div>
          {user && (
            <div className="ml-auto text-sm text-muted-foreground">
              {user.name}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6 space-y-8">
        {/* Explicación */}
        <Card className="bg-primary/5 border-primary/30">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <Calculator className="w-8 h-8 text-primary mt-1" />
              <div>
                <h3 className="font-bold text-primary mb-2">¿Por qué configurar tu plan?</h3>
                <p className="text-muted-foreground mb-4">
                  Definir tu capital inicial y meta diaria te permite tener objetivos claros y calcular 
                  proyecciones realistas de crecimiento. Este plan será la base para todas tus operaciones.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-success" />
                    <span>Capital inicial: Base de tu trading</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-primary" />
                    <span>Meta diaria: % diario objetivo</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-success" />
                    <span>Crecimiento compuesto</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span>250 días trading/año</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Formulario de configuración */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                Configurar Plan de Trading
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Capital inicial */}
                <div className="space-y-2">
                  <Label htmlFor="capitalInicial" className="text-primary font-medium">
                    Capital Inicial (USD)
                  </Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="capitalInicial"
                      type="number"
                      min="100"
                      max="1000000"
                      step="0.01"
                      value={formData.capitalInicial}
                      onChange={(e) => handleInputChange('capitalInicial', e.target.value)}
                      placeholder="10000"
                      className="pl-10 border-primary/30 focus:border-primary"
                      required
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Monto inicial con el que empiezas a operar
                  </p>
                </div>

                {/* Meta diaria en porcentaje */}
                <div className="space-y-2">
                  <Label htmlFor="metaDiariaPercent" className="text-primary font-medium">
                    Meta Diaria (% del capital)
                  </Label>
                  <div className="relative">
                    <Target className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="metaDiariaPercent"
                      type="number"
                      min="0.1"
                      max="10"
                      step="0.1"
                      value={formData.metaDiariaPercent}
                      onChange={(e) => handleInputChange('metaDiariaPercent', e.target.value)}
                      placeholder="1.0"
                      className="pl-10 border-primary/30 focus:border-primary"
                      required
                    />
                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                      %
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Porcentaje que buscas ganar diariamente (recomendado: 0.5% - 2%)
                  </p>
                  
                  {currentDailyGoal > 0 && (
                    <div className="mt-2 p-3 bg-success/10 rounded-lg border border-success/30">
                      <p className="text-sm text-success font-medium">
                        Meta diaria: ${currentDailyGoal.toLocaleString('es-CL')} USD
                      </p>
                    </div>
                  )}
                </div>

                {/* Alertas */}
                {alert.type && (
                  <Alert className={
                    alert.type === 'success' 
                      ? 'bg-success/10 border-success/30' 
                      : alert.type === 'info'
                      ? 'bg-primary/10 border-primary/30'
                      : 'bg-destructive/10 border-destructive/30'
                  }>
                    <div className="flex items-start gap-2">
                      {alert.type === 'success' ? (
                        <CheckCircle className="w-4 h-4 text-success mt-0.5" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-destructive mt-0.5" />
                      )}
                      <AlertDescription className={
                        alert.type === 'success' 
                          ? 'text-success' 
                          : alert.type === 'info'
                          ? 'text-primary'
                          : 'text-destructive'
                      }>
                        {alert.message}
                      </AlertDescription>
                    </div>
                  </Alert>
                )}

                {/* Botón de guardar */}
                <Button 
                  type="submit" 
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin"></div>
                      Guardando plan...
                    </div>
                  ) : (
                    'Guardar Plan de Trading'
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Proyecciones */}
          {projections.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-success" />
                  Proyecciones de Crecimiento
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground mb-4">
                  Proyecciones basadas en crecimiento compuesto diario
                </p>
                
                {projections.map((projection, index) => (
                  <div key={index} className="p-4 bg-card/50 rounded-lg border">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium text-primary">En {projection.periodo}</h4>
                      <span className="text-xs text-muted-foreground">
                        {projection.diasTradingAnuales} días trading
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Capital Final:</span>
                        <span className="font-medium text-success">
                          ${projection.capitalFinal.toLocaleString('es-CL', { maximumFractionDigits: 0 })} USD
                        </span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Profit Total:</span>
                        <span className="font-medium text-primary">
                          ${projection.profitTotal.toLocaleString('es-CL', { maximumFractionDigits: 0 })} USD
                        </span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Multiplicador:</span>
                        <span className="font-medium text-foreground">
                          {(projection.capitalFinal / parseFloat(formData.capitalInicial)).toFixed(1)}x
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
                
                <div className="mt-4 p-3 bg-primary/10 rounded-lg border border-primary/30">
                  <p className="text-xs text-primary">
                    💡 <strong>Nota:</strong> Estas proyecciones asumen rendimiento constante. 
                    Los resultados reales pueden variar según las condiciones del mercado.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}