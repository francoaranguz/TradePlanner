import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  ArrowLeft, 
  Download, 
  Copy, 
  RefreshCw, 
  CheckCircle, 
  AlertCircle, 
  Folder,
  Settings,
  Link2,
  Key,
  Wifi,
  WifiOff,
  FileText,
  Monitor,
  BarChart3
} from 'lucide-react';
import { 
  getOrCreateApiKey, 
  regenerateApiKey, 
  copyToClipboard, 
  getConnectionStatus,
  setMT5Integration,
  hasMT5Integration,
  ApiKey 
} from './utils/integration-utils';

interface User {
  email: string;
  name: string;
}

interface IntegrationsProps {
  onBack: () => void;
  onViewOperations: () => void;
  user: User | null;
}

export function Integrations({ onBack, onViewOperations, user }: IntegrationsProps) {
  const [apiKey, setApiKey] = useState<ApiKey | null>(null);
  const [copySuccess, setCopySuccess] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState({ connected: false, lastUpdate: null });

  useEffect(() => {
    // Cargar API Key
    const key = getOrCreateApiKey();
    setApiKey(key);

    // Verificar estado de conexión
    const status = getConnectionStatus();
    setConnectionStatus(status);

    // Simular actualización periódica del estado de conexión
    const interval = setInterval(() => {
      const newStatus = getConnectionStatus();
      setConnectionStatus(newStatus);
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const handleCopyApiKey = async () => {
    if (!apiKey) return;
    
    const success = await copyToClipboard(apiKey.key);
    if (success) {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    }
  };

  const handleRegenerateApiKey = async () => {
    setIsRegenerating(true);
    
    // Simular delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newKey = regenerateApiKey();
    setApiKey(newKey);
    setIsRegenerating(false);
  };

  const handleDownloadPlugin = () => {
    // Simular descarga de plugin y marcar como configurada la integración
    const link = document.createElement('a');
    link.href = '#';
    link.download = 'TradingPlanner_MT5_Plugin.zip';
    link.click();
    
    // Activar integración MT5 (simular que el usuario ha comenzado el proceso)
    setMT5Integration(true);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-muted p-4">
        <div className="max-w-6xl mx-auto flex items-center gap-4">
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-primary"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver
          </Button>
          <div className="flex items-center gap-3">
            <Link2 className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-bold text-primary">Integraciones</h1>
          </div>
          {user && (
            <div className="ml-auto text-sm text-muted-foreground">
              {user.name}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6 space-y-8">
        {/* Descripción */}
        <Card className="bg-primary/5 border-primary/30">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <Monitor className="w-8 h-8 text-primary mt-1" />
              <div>
                <h3 className="font-bold text-primary mb-2">Conecta MetaTrader 5 con Trading Planner</h3>
                <p className="text-muted-foreground mb-4">
                  Sincroniza automáticamente tus operaciones de MT5 con Trading Planner para análisis 
                  detallado, seguimiento de KPIs y gestión avanzada de riesgo en tiempo real.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-success" />
                    <span>Análisis automático de operaciones</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Wifi className="w-4 h-4 text-primary" />
                    <span>Sincronización en tiempo real</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-success" />
                    <span>KPIs y métricas avanzadas</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Plugin MT5 */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="w-5 h-5 text-primary" />
                  Plugin MT5 (Windows)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground text-sm">
                  Descarga e instala el Expert Advisor para conectar tu MT5 con Trading Planner.
                </p>
                
                <div className="flex items-center gap-4 p-4 bg-muted/20 rounded-lg">
                  <FileText className="w-6 h-6 text-primary" />
                  <div className="flex-1">
                    <p className="font-medium">TradingPlanner_MT5_Plugin.zip</p>
                    <p className="text-sm text-muted-foreground">Incluye: TradingPlanner.ex5 + README.txt</p>
                  </div>
                  <Button 
                    onClick={handleDownloadPlugin}
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Descargar ZIP
                  </Button>
                </div>

                <Alert className="bg-primary/10 border-primary/30">
                  <AlertCircle className="w-4 h-4 text-primary" />
                  <AlertDescription className="text-primary">
                    <strong>Requisitos:</strong> MetaTrader 5 build 3815 o superior. Compatible con Windows 10/11.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            {/* Tu API Key */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5 text-primary" />
                  Tu API Key
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground text-sm">
                  Copia esta clave y pégala en el Expert Advisor para autenticar la conexión.
                </p>
                
                {apiKey && (
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <Input
                        value={apiKey.key}
                        readOnly
                        className="font-mono text-sm bg-muted/50"
                      />
                      <Button
                        onClick={handleCopyApiKey}
                        size="sm"
                        variant="outline"
                        className={copySuccess ? "border-success text-success" : "border-primary text-primary hover:bg-primary hover:text-primary-foreground"}
                      >
                        {copySuccess ? (
                          <CheckCircle className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>

                    <div className="flex justify-between items-center text-sm text-muted-foreground">
                      <span>Creada: {new Date(apiKey.created).toLocaleDateString('es-CL')}</span>
                      <Button
                        onClick={handleRegenerateApiKey}
                        size="sm"
                        variant="ghost"
                        disabled={isRegenerating}
                        className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        {isRegenerating ? (
                          <RefreshCw className="w-4 h-4 mr-1 animate-spin" />
                        ) : (
                          <RefreshCw className="w-4 h-4 mr-1" />
                        )}
                        Regenerar
                      </Button>
                    </div>

                    {copySuccess && (
                      <Alert className="bg-success/10 border-success/30">
                        <CheckCircle className="w-4 h-4 text-success" />
                        <AlertDescription className="text-success">
                          API Key copiada al portapapeles
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Pasos de instalación */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-primary" />
                  Pasos de Instalación
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Paso 1 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                      1
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Folder className="w-4 h-4 text-primary" />
                        <h4 className="font-medium">Copiar archivo EA</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        En MT5: <code className="bg-muted px-1 rounded">File → Open Data Folder → MQL5/Experts</code>
                        <br />
                        Copia el archivo <code className="bg-muted px-1 rounded">TradingPlanner.ex5</code>
                      </p>
                    </div>
                  </div>

                  <Separator />

                  {/* Paso 2 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                      2
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Settings className="w-4 h-4 text-primary" />
                        <h4 className="font-medium">Configurar WebRequest</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        <code className="bg-muted px-1 rounded">Tools → Options → Expert Advisors</code>
                        <br />
                        Agregar URL: <code className="bg-muted px-1 rounded">https://trading-planner.app</code>
                      </p>
                    </div>
                  </div>

                  <Separator />

                  {/* Paso 3 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                      3
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-primary" />
                        <h4 className="font-medium">Activar EA</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Arrastra el EA al gráfico → Permitir WebRequest
                        <br />
                        Pega tu API Key en el parámetro correspondiente
                      </p>
                    </div>
                  </div>

                  <Alert className="bg-success/10 border-success/30">
                    <CheckCircle className="w-4 h-4 text-success" />
                    <AlertDescription className="text-success">
                      <strong>¡Listo!</strong> El EA enviará automáticamente tus operaciones a Trading Planner.
                    </AlertDescription>
                  </Alert>
                </div>
              </CardContent>
            </Card>

            {/* Estado de conexión */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {connectionStatus.connected ? (
                    <Wifi className="w-5 h-5 text-success" />
                  ) : (
                    <WifiOff className="w-5 h-5 text-destructive" />
                  )}
                  Estado de Conexión
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Estado:</span>
                  <Badge variant={connectionStatus.connected ? "default" : "destructive"} className={
                    connectionStatus.connected 
                      ? "bg-success text-success-foreground" 
                      : "bg-destructive text-destructive-foreground"
                  }>
                    {connectionStatus.connected ? "Recibiendo datos" : "Sin conexión"}
                  </Badge>
                </div>

                {connectionStatus.lastUpdate && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Última actualización:</span>
                    <span className="text-sm text-muted-foreground">
                      {new Date(connectionStatus.lastUpdate).toLocaleString('es-CL')}
                    </span>
                  </div>
                )}

                <Separator />

                <Button 
                  onClick={onViewOperations}
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  disabled={!connectionStatus.connected}
                >
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Ver Operaciones
                </Button>

                {!connectionStatus.connected && (
                  <p className="text-xs text-muted-foreground text-center">
                    Conecta el EA para ver tus operaciones en tiempo real
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Soporte */}
        <Card className="bg-muted/20">
          <CardContent className="p-6">
            <div className="text-center space-y-2">
              <h3 className="font-medium">¿Necesitas ayuda?</h3>
              <p className="text-sm text-muted-foreground">
                Consulta la documentación completa o contacta nuestro soporte técnico
              </p>
              <div className="flex justify-center gap-4 mt-4">
                <Button variant="outline" size="sm">
                  <FileText className="w-4 h-4 mr-2" />
                  Documentación
                </Button>
                <Button variant="outline" size="sm">
                  <AlertCircle className="w-4 h-4 mr-2" />
                  Soporte
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}