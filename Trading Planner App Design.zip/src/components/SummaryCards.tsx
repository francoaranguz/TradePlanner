import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { DollarSign, Target, TrendingUp, AlertTriangle, PieChart, Calendar } from 'lucide-react';
import { getSummaryData } from './constants/app-constants';

export function SummaryCards() {
  const summaryData = getSummaryData();
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-primary" />
            Saldo Inicial del Día
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-foreground">
            ${summaryData.saldoInicial.toLocaleString('es-CL')}
          </p>
        </CardContent>
      </Card>

      <Card className="bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Target className="w-4 h-4 text-primary" />
            Meta del Día
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-primary">
            ${summaryData.metaDia.toLocaleString('es-CL')}
          </p>
        </CardContent>
      </Card>

      <Card className="bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-success" />
            Avance del Plan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-success">
            {summaryData.avancePlan.porcentaje}%
          </p>
          <p className="text-sm text-muted-foreground">
            ${summaryData.avancePlan.monto.toLocaleString('es-CL')}
          </p>
        </CardContent>
      </Card>

      <Card className="bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-destructive" />
            Riesgo por Operación
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-destructive">
            {summaryData.riesgoOperacion.porcentaje}%
          </p>
          <p className="text-sm text-muted-foreground">
            ${summaryData.riesgoOperacion.monto.toLocaleString('es-CL')}
          </p>
        </CardContent>
      </Card>

      <Card className="bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <PieChart className="w-4 h-4 text-destructive" />
            Riesgo Total Permitido
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-destructive">
            {summaryData.riesgoTotal.porcentaje}%
          </p>
          <p className="text-sm text-muted-foreground">
            ${summaryData.riesgoTotal.monto.toLocaleString('es-CL')}
          </p>
        </CardContent>
      </Card>

      <Card className="bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" />
            Profit Diario Plan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-primary">
            ${summaryData.profitDiario.toLocaleString('es-CL')}
          </p>
        </CardContent>
      </Card>

      <Card className="bg-card/50 md:col-span-2">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-success" />
            Profit Acumulación Meta Diaria
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-success">
            ${summaryData.profitAcumulado.toLocaleString('es-CL')}
          </p>
          <p className="text-sm text-muted-foreground">
            Acumulado desde inicio del plan
          </p>
        </CardContent>
      </Card>
    </div>
  );
}