import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription } from './ui/sheet';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Download, User, Settings, Rocket, BarChart3, Link2, LogOut, Menu, Calculator, FileText } from 'lucide-react';
import { SummaryCards } from './SummaryCards';
import { TradingOperations } from './TradingOperations';
import { UserMenu } from './UserMenu';
import { useIsMobile } from './ui/use-mobile';
import { motivationalMessages } from './constants/app-constants';
import { generateMockData, exportChartToExcel } from './utils/chart-utils';
import { getSavedPlan, generateProjectionMessage, isPlanConfigured, calculateProjections } from './utils/plan-utils';
import { hasMT5Integration } from './utils/integration-utils';
import { User as UserType } from './utils/auth-utils';

interface DashboardProps {
  onNavigateToRegister: () => void;
  onNavigateToCalculator: () => void;
  onNavigateToConfig: () => void;
  onNavigateToIntegrations: () => void;
  user: UserType | null;
  onLogout: () => void;
}

export function Dashboard({ onNavigateToRegister, onNavigateToCalculator, onNavigateToConfig, onNavigateToIntegrations, user, onLogout }: DashboardProps) {
  const [chartView, setChartView] = useState('daily');
  const chartData = generateMockData(chartView);
  const [currentMessage, setCurrentMessage] = useState(motivationalMessages[0]);
  const [planConfigured, setPlanConfigured] = useState(false);
  const [projectionMessages, setProjectionMessages] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState('overview');
  const [mt5Integration, setMt5Integration] = useState(false);
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const isMobile = useIsMobile();

  // Verificar si el plan está configurado y generar mensajes de proyección
  useEffect(() => {
    const checkConfiguration = () => {
      const isConfigured = isPlanConfigured();
      setPlanConfigured(isConfigured);

      // Verificar integración MT5
      const hasMT5 = hasMT5Integration();
      setMt5Integration(hasMT5);

      if (isConfigured) {
        const savedPlan = getSavedPlan();
        if (savedPlan) {
          const projections = calculateProjections(savedPlan);
          const messages = [
            generateProjectionMessage(savedPlan),
            `🎯 En 2 años: ${projections[1].capitalFinal.toLocaleString('es-CL', { maximumFractionDigits: 0 })} USD de balance total`,
            `💎 En 3 años: ${projections[2].capitalFinal.toLocaleString('es-CL', { maximumFractionDigits: 0 })} USD - ¡${(projections[2].capitalFinal / savedPlan.capitalInicial).toFixed(1)}x tu capital inicial!`
          ];
          setProjectionMessages(messages);
          setCurrentMessage(messages[0]);
        }
      } else {
        setCurrentMessage("⚙️ Configura tu plan de trading para ver proyecciones personalizadas");
      }
    };

    checkConfiguration();

    // Escuchar cambios en localStorage para actualizar integración MT5
    const handleStorageChange = () => {
      checkConfiguration();
    };

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  // Re-verificar configuración cuando se navegue de vuelta al dashboard
  useEffect(() => {
    const isConfigured = isPlanConfigured();
    setPlanConfigured(isConfigured);
    
    const hasMT5 = hasMT5Integration();
    setMt5Integration(hasMT5);
  }, [activeTab]); // Triggers when tabs change, indicating user returned to dashboard

  const handleExportToExcel = () => {
    exportChartToExcel(chartData, chartView);
  };

  // Componente de navegación móvil
  const MobileNavigation = () => (
    <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="md:hidden p-2"
        >
          <Menu className="w-5 h-5 text-primary" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="bg-card border-l border-border">
        <SheetHeader>
          <SheetTitle className="text-primary">Menú Principal</SheetTitle>
          <SheetDescription className="text-muted-foreground">
            Accede a todas las funciones del Trading Planner
          </SheetDescription>
        </SheetHeader>
        <div className="flex flex-col gap-4 mt-6">
          <Button 
            onClick={() => {
              onNavigateToRegister();
              setIsSheetOpen(false);
            }}
            className="w-full justify-start bg-primary text-primary-foreground hover:bg-primary/90"
            disabled={!planConfigured}
          >
            <FileText className="w-4 h-4 mr-2" />
            Registrar Día
          </Button>
          <Button 
            onClick={() => {
              onNavigateToCalculator();
              setIsSheetOpen(false);
            }}
            className="w-full justify-start bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Calculator className="w-4 h-4 mr-2" />
            Calculadora de Lotes
          </Button>
          <Button 
            onClick={() => {
              onNavigateToConfig();
              setIsSheetOpen(false);
            }}
            variant="outline"
            className="w-full justify-start border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            <Settings className="w-4 h-4 mr-2" />
            Configuración
          </Button>
          <Button 
            onClick={() => {
              onNavigateToIntegrations();
              setIsSheetOpen(false);
            }}
            variant="outline"
            className="w-full justify-start border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            <Link2 className="w-4 h-4 mr-2" />
            Integraciones
          </Button>
          <div className="border-t border-border pt-4">
            <Button 
              onClick={() => {
                onLogout();
                setIsSheetOpen(false);
              }}
              variant="ghost"
              className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Barra superior fija */}
      <div className="sticky top-0 z-50 bg-card border-b border-muted p-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2 md:gap-4">
            <h1 className="text-xl md:text-2xl font-bold text-primary">Trading Planner</h1>
            {user && !isMobile && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <User className="w-4 h-4" />
                <span className="text-sm">Bienvenido, <span className="text-primary font-medium">{user.name}</span></span>
              </div>
            )}
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            {/* Navegación Desktop */}
            {!isMobile && (
              <>
                <Button 
                  onClick={onNavigateToRegister}
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                  disabled={!planConfigured}
                >
                  Registrar Día
                </Button>
                <Button 
                  onClick={onNavigateToCalculator}
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  Calculadora de Lotes
                </Button>
                {user && (
                  <UserMenu
                    user={user}
                    onNavigateToConfig={onNavigateToConfig}
                    onNavigateToIntegrations={onNavigateToIntegrations}
                    onLogout={onLogout}
                  />
                )}
              </>
            )}
            
            {/* Navegación Mobile */}
            {isMobile && <MobileNavigation />}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-6 md:space-y-8">
        {/* Mensaje motivacional con proyecciones */}
        <Card className="bg-gradient-to-r from-primary/20 to-primary/10 border-primary/30">
          <CardContent className="p-4 md:p-8 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              {planConfigured && <Rocket className="w-5 h-5 md:w-6 md:h-6 text-primary" />}
              <p className="text-lg md:text-2xl font-bold text-primary">{currentMessage}</p>
            </div>
            <p className="text-sm md:text-base text-muted-foreground mb-4">
              {planConfigured 
                ? "La constancia y disciplina harán realidad estas proyecciones" 
                : "La clave del éxito está en la constancia y la disciplina"
              }
            </p>
            
            {/* Mostrar proyecciones adicionales si el plan está configurado */}
            {planConfigured && projectionMessages.length > 1 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4 mt-4">
                {projectionMessages.slice(1).map((message, index) => (
                  <div key={index} className="p-3 bg-primary/10 rounded-lg border border-primary/20">
                    <p className="text-xs md:text-sm font-medium text-primary">{message}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Botón para configurar plan si no está configurado */}
            {!planConfigured && (
              <Button 
                onClick={onNavigateToConfig}
                className="mt-4 bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Settings className="w-4 h-4 mr-2" />
                Configurar Mi Plan Ahora
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Contenido principal con tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className={`grid w-full ${mt5Integration ? 'grid-cols-2' : 'grid-cols-1'} bg-muted/50`}>
            <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <TrendingUp className="w-4 h-4 mr-2" />
              Resumen
            </TabsTrigger>
            {mt5Integration && (
              <TabsTrigger value="operations" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <BarChart3 className="w-4 h-4 mr-2" />
                Operaciones
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            {/* Cuadros de resumen */}
            <SummaryCards />

            {/* Gráfico de progreso */}
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    Progreso de Trading
                  </CardTitle>
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                    <Select value={chartView} onValueChange={setChartView}>
                      <SelectTrigger className="w-full sm:w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Vista Diaria (Mes Actual)</SelectItem>
                        <SelectItem value="weekly">Vista Semanal (6 Meses)</SelectItem>
                        <SelectItem value="monthly">Vista Mensual (Año Actual)</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button 
                      onClick={handleExportToExcel}
                      variant="outline"
                      size="sm"
                      className="w-full sm:w-auto border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      {isMobile ? 'Exportar' : 'Exportar a Excel'}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className={`${isMobile ? 'h-64' : 'h-96'}`}>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart 
                      data={chartData}
                      margin={{
                        top: 10,
                        right: isMobile ? 5 : 30,
                        left: isMobile ? 0 : 20,
                        bottom: isMobile ? 40 : 10
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#333333" />
                      <XAxis 
                        dataKey="period" 
                        stroke="#cccccc" 
                        fontSize={isMobile ? 10 : 12}
                        angle={isMobile ? -45 : 0}
                        textAnchor={isMobile ? 'end' : 'middle'}
                        height={isMobile ? 50 : 30}
                      />
                      <YAxis 
                        stroke="#cccccc" 
                        fontSize={isMobile ? 9 : 12}
                        width={isMobile ? 40 : 60}
                        tickFormatter={(value) => {
                          if (value >= 1000000) {
                            return `${(value / 1000000).toFixed(1)}M`;
                          } else if (value >= 1000) {
                            return `${Math.round(value / 1000)}K`;
                          }
                          return value.toLocaleString('es-CL');
                        }}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1a1a1a', 
                          border: '1px solid #ffd700',
                          borderRadius: '8px',
                          fontSize: isMobile ? '12px' : '14px'
                        }}
                        labelStyle={{ color: '#ffffff' }}
                        formatter={(value: any) => [
                          `$${typeof value === 'number' ? value.toLocaleString('es-CL') : value}`,
                          ''
                        ]}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="saldo" 
                        stroke="#00ff7f" 
                        strokeWidth={isMobile ? 2 : 3}
                        name="Saldo Real"
                        dot={{ fill: '#00ff7f', strokeWidth: 2, r: isMobile ? 3 : 4 }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="meta" 
                        stroke="#ffd700" 
                        strokeWidth={isMobile ? 1.5 : 2}
                        strokeDasharray="5 5"
                        name="Meta"
                        dot={{ fill: '#ffd700', strokeWidth: 2, r: isMobile ? 2 : 3 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {mt5Integration && (
            <TabsContent value="operations" className="space-y-6">
              <TradingOperations onNavigateToIntegrations={onNavigateToIntegrations} />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  );
}