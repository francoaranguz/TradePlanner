import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { User, Lock, Eye, EyeOff, TrendingUp, AlertCircle, CheckCircle, Chrome } from 'lucide-react';
import { 
  authenticateUser, 
  registerUser, 
  signInWithGoogle
} from './utils/auth-utils';
import { demoUsers } from './constants/app-constants';

interface LoginProps {
  onLogin: (userData: { email: string; name: string }) => void;
}

export function Login({ onLogin }: LoginProps) {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: ''
  });
  const [isRegistering, setIsRegistering] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | null; message: string }>({
    type: null,
    message: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [oauthLoading, setOauthLoading] = useState<'google' | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setAlert({ type: null, message: '' });

    try {
      if (isRegistering) {
        const result = await registerUser(formData.email, formData.password, formData.name);
        if (result.success && result.user) {
          setAlert({ type: 'success', message: result.message });
          setTimeout(() => {
            onLogin(result.user!);
          }, 1500);
        } else {
          setAlert({ type: 'error', message: result.message });
        }
      } else {
        const result = await authenticateUser(formData.email, formData.password);
        if (result.success && result.user) {
          setAlert({ type: 'success', message: result.message });
          setTimeout(() => {
            onLogin(result.user!);
          }, 1500);
        } else {
          setAlert({ type: 'error', message: result.message });
        }
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'Error inesperado. Intenta nuevamente.' });
    }

    setIsLoading(false);
  };

  const handleOAuthLogin = async () => {
    setOauthLoading('google');
    setAlert({ type: null, message: '' });

    try {
      const result = await signInWithGoogle();

      if (result.success && result.user) {
        setAlert({ type: 'success', message: result.message });
        setTimeout(() => {
          onLogin(result.user!);
        }, 1500);
      } else {
        setAlert({ type: 'error', message: result.message });
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'Error al conectar con el servicio. Intenta nuevamente.' });
    }

    setOauthLoading(null);
  };

  const handleDemoLogin = () => {
    const demoUser = demoUsers[0];
    setFormData({
      email: demoUser.email,
      password: demoUser.password,
      name: demoUser.name
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-6">
      <div className="w-full max-w-md space-y-8">
        {/* Logo y título */}
        <div className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-primary rounded-full flex items-center justify-center">
            <TrendingUp className="w-8 h-8 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-primary">Trading Planner</h1>
            <p className="text-muted-foreground mt-2">
              {isRegistering ? 'Crea tu cuenta de trader' : 'Inicia sesión en tu cuenta'}
            </p>
          </div>
        </div>

        {/* Formulario de login/registro */}
        <Card className="bg-card/50 border-primary/20">
          <CardHeader>
            <CardTitle className="text-center text-primary">
              {isRegistering ? 'Registro de Usuario' : 'Iniciar Sesión'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Nombre (solo para registro) */}
              {isRegistering && (
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-primary font-medium">
                    Nombre Completo
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="name"
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Tu nombre completo"
                      className="pl-10 border-primary/30 focus:border-primary"
                      required={isRegistering}
                    />
                  </div>
                </div>
              )}

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-primary font-medium">
                  Email
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="tu@email.com"
                    className="pl-10 border-primary/30 focus:border-primary"
                    required
                  />
                </div>
              </div>

              {/* Contraseña */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-primary font-medium">
                  Contraseña
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Tu contraseña"
                    className="pl-10 pr-10 border-primary/30 focus:border-primary"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0 text-muted-foreground hover:text-primary"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
                {isRegistering && (
                  <p className="text-sm text-muted-foreground">
                    Mínimo 6 caracteres
                  </p>
                )}
              </div>

              {/* Alertas */}
              {alert.type && (
                <Alert className={
                  alert.type === 'success' 
                    ? 'bg-success/10 border-success/30' 
                    : 'bg-destructive/10 border-destructive/30'
                }>
                  <div className="flex items-start gap-2">
                    {alert.type === 'success' ? (
                      <CheckCircle className="w-4 h-4 text-success mt-0.5" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-destructive mt-0.5" />
                    )}
                    <AlertDescription className={
                      alert.type === 'success' ? 'text-success' : 'text-destructive'
                    }>
                      {alert.message}
                    </AlertDescription>
                  </div>
                </Alert>
              )}

              {/* Botón de submit */}
              <Button 
                type="submit" 
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin"></div>
                    {isRegistering ? 'Creando cuenta...' : 'Iniciando sesión...'}
                  </div>
                ) : (
                  isRegistering ? 'Crear Cuenta' : 'Iniciar Sesión'
                )}
              </Button>

              {/* OAuth Buttons - Solo mostrar en login */}
              {!isRegistering && (
                <>
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <Separator className="w-full" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-card px-2 text-muted-foreground">
                        O continúa con
                      </span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {/* Google */}
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full border-muted-foreground/20 hover:bg-muted/20"
                      onClick={handleOAuthLogin}
                      disabled={oauthLoading !== null}
                    >
                      {oauthLoading === 'google' ? (
                        <div className="w-4 h-4 border-2 border-muted-foreground/30 border-t-muted-foreground rounded-full animate-spin mr-2"></div>
                      ) : (
                        <Chrome className="w-4 h-4 mr-2 text-primary" />
                      )}
                      Continuar con Google
                    </Button>
                  </div>
                </>
              )}

              {/* Cambiar entre login y registro */}
              <div className="text-center">
                <Button 
                  type="button"
                  variant="ghost" 
                  onClick={() => {
                    setIsRegistering(!isRegistering);
                    setAlert({ type: null, message: '' });
                    setFormData({ email: '', password: '', name: '' });
                  }}
                  className="text-primary hover:text-primary/80"
                >
                  {isRegistering 
                    ? '¿Ya tienes cuenta? Inicia sesión' 
                    : '¿No tienes cuenta? Regístrate'
                  }
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Acceso demo */}
        {!isRegistering && (
          <Card className="bg-muted/30 border-muted">
            <CardContent className="p-4">
              <div className="text-center space-y-3">
                <p className="text-sm text-muted-foreground">
                  💡 <strong>Demo rápido:</strong> Prueba la aplicación sin registro
                </p>
                <Button 
                  onClick={handleDemoLogin}
                  variant="outline"
                  size="sm"
                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                >
                  Cargar Credenciales Demo
                </Button>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>Email: demo@tradingplanner.cl</p>
                  <p>Contraseña: demo123</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Footer */}
        <div className="text-center text-sm text-muted-foreground">
          <p>© 2025 Trading Planner</p>
          <p>La disciplina es tu mayor ganancia 💪</p>
        </div>
      </div>
    </div>
  );
}