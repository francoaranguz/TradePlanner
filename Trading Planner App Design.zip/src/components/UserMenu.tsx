import { User, Settings, Plug, LogOut, UserCircle } from 'lucide-react';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { User as UserType } from './utils/auth-utils';

interface UserMenuProps {
  user: UserType;
  onNavigateToConfig: () => void;
  onNavigateToIntegrations: () => void;
  onLogout: () => void;
}

export function UserMenu({ user, onNavigateToConfig, onNavigateToIntegrations, onLogout }: UserMenuProps) {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getProviderIcon = (provider?: string) => {
    switch (provider) {
      case 'google':
        return '🔍';
      case 'apple':
        return '🍎';
      case 'facebook':
        return '📘';
      default:
        return '✉️';
    }
  };

  const getProviderLabel = (provider?: string) => {
    switch (provider) {
      case 'google':
        return 'Cuenta Google';
      case 'apple':
        return 'Cuenta Apple';
      case 'facebook':
        return 'Cuenta Facebook';
      default:
        return 'Cuenta Email';
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="ghost" 
          className="relative h-10 w-10 rounded-full border border-primary/20 hover:bg-primary/10"
        >
          <Avatar className="h-9 w-9">
            <AvatarImage src={user.avatar} alt={user.name} />
            <AvatarFallback className="bg-primary text-primary-foreground font-medium">
              {getInitials(user.name)}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        className="w-72 bg-card border-primary/20 shadow-lg" 
        align="end" 
        forceMount
      >
        <DropdownMenuLabel className="font-normal p-4">
          <div className="flex items-start gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback className="bg-primary text-primary-foreground font-medium">
                {getInitials(user.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col space-y-1 flex-1 min-w-0">
              <p className="font-medium leading-none text-primary truncate">
                {user.name}
              </p>
              <p className="text-xs leading-none text-muted-foreground truncate">
                {user.email}
              </p>
              <div className="flex items-center gap-1 mt-1">
                <span className="text-xs opacity-70">
                  {getProviderIcon(user.provider)}
                </span>
                <span className="text-xs text-muted-foreground">
                  {getProviderLabel(user.provider)}
                </span>
              </div>
            </div>
          </div>
        </DropdownMenuLabel>
        
        <DropdownMenuSeparator className="bg-primary/20" />
        
        <DropdownMenuItem 
          onClick={onNavigateToConfig}
          className="cursor-pointer hover:bg-primary/10 focus:bg-primary/10 py-3 px-4"
        >
          <Settings className="mr-3 h-4 w-4 text-primary" />
          <div className="flex flex-col">
            <span className="text-sm font-medium">Configurar Plan</span>
            <span className="text-xs text-muted-foreground">Capital inicial y metas</span>
          </div>
        </DropdownMenuItem>
        
        <DropdownMenuItem 
          onClick={onNavigateToIntegrations}
          className="cursor-pointer hover:bg-primary/10 focus:bg-primary/10 py-3 px-4"
        >
          <Plug className="mr-3 h-4 w-4 text-primary" />
          <div className="flex flex-col">
            <span className="text-sm font-medium">Integraciones</span>
            <span className="text-xs text-muted-foreground">MT5 y herramientas externas</span>
          </div>
        </DropdownMenuItem>
        
        <DropdownMenuSeparator className="bg-primary/20" />
        
        <DropdownMenuItem 
          onClick={onLogout}
          className="cursor-pointer hover:bg-destructive/10 focus:bg-destructive/10 py-3 px-4"
        >
          <LogOut className="mr-3 h-4 w-4 text-destructive" />
          <div className="flex flex-col">
            <span className="text-sm font-medium text-destructive">Cerrar Sesión</span>
            <span className="text-xs text-muted-foreground">Salir de la aplicación</span>
          </div>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}