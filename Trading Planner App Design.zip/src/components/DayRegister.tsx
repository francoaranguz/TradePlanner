import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { ArrowLeft, Calendar, DollarSign, TrendingUp, Calculator, AlertCircle, CheckCircle, AlertTriangle, Minus, CreditCard } from 'lucide-react';
import { 
  saveWithdrawal, 
  validateWithdrawal, 
  getWithdrawalsByDate,
  WithdrawalRecord 
} from './utils/withdrawal-utils';

interface User {
  email: string;
  name: string;
}

interface DayRegisterProps {
  onBack: () => void;
  user: User | null;
}

export function DayRegister({ onBack, user }: DayRegisterProps) {
  const [saldoReal, setSaldoReal] = useState<string>('');
  const [showResult, setShowResult] = useState(false);
  const [resultType, setResultType] = useState<'success' | 'warning' | 'danger'>('success');
  
  // Estados para retiros
  const [hizoRetiro, setHizoRetiro] = useState<boolean | null>(null);
  const [montoRetiro, setMontoRetiro] = useState<string>('');
  const [tipoRetiro, setTipoRetiro] = useState<'profit' | 'balance'>('profit');
  const [notasRetiro, setNotasRetiro] = useState<string>('');
  const [withdrawalAlert, setWithdrawalAlert] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Datos del plan (normalmente vendrían de un contexto o estado global)
  const planData = {
    saldoInicial: 15750.00,
    metaDia: 157.50,
    porcentajeRetiro: 0.7, // 70% para retiro
    porcentajeAcumulacion: 0.3 // 30% para acumulación
  };

  const currentDate = new Date().toLocaleDateString('es-CL', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const todayDate = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const saldoNumerico = parseFloat(saldoReal);
    if (isNaN(saldoNumerico)) return;

    const diferencia = saldoNumerico - planData.saldoInicial;
    const metaAlcanzada = diferencia / planData.metaDia;

    if (metaAlcanzada >= 0.95) { // 95% o más de la meta
      setResultType('success');
    } else if (metaAlcanzada >= 0.7) { // 70% - 94% de la meta
      setResultType('warning');
    } else { // Menos del 70% de la meta
      setResultType('danger');
    }

    setShowResult(true);
  };

  const handleWithdrawalSubmit = () => {
    if (!hizoRetiro || !montoRetiro) return;

    const monto = parseFloat(montoRetiro);
    const validation = validateWithdrawal(monto, tipoRetiro);

    if (!validation.valid) {
      setWithdrawalAlert({ type: 'error', message: validation.message });
      return;
    }

    try {
      saveWithdrawal({
        fecha: todayDate,
        monto,
        tipo: tipoRetiro,
        notas: notasRetiro || undefined
      });

      setWithdrawalAlert({ 
        type: 'success', 
        message: `Retiro de ${monto.toLocaleString('es-CL')} registrado exitosamente.` 
      });
      
      // Limpiar formulario después de 2 segundos
      setTimeout(() => {
        setMontoRetiro('');
        setNotasRetiro('');
        setWithdrawalAlert(null);
      }, 2000);
    } catch (error) {
      setWithdrawalAlert({ 
        type: 'error', 
        message: 'Error al guardar el retiro. Intenta nuevamente.' 
      });
    }
  };

  const calculateResults = () => {
    const saldoNumerico = parseFloat(saldoReal);
    if (isNaN(saldoNumerico)) return { profitRetiro: 0, profitAcumulacion: 0, profitTotal: 0 };

    const profitTotal = Math.max(0, saldoNumerico - planData.saldoInicial);
    const profitRetiro = profitTotal * planData.porcentajeRetiro;
    const profitAcumulacion = profitTotal * planData.porcentajeAcumulacion;

    return { profitRetiro, profitAcumulacion, profitTotal };
  };

  const { profitRetiro, profitAcumulacion, profitTotal } = calculateResults();

  const getResultMessage = () => {
    const metaAlcanzada = (profitTotal / planData.metaDia) * 100;
    
    switch (resultType) {
      case 'success':
        return {
          icon: <CheckCircle className="w-6 h-6 text-success" />,
          title: '¡Excelente trabajo! 🎉',
          message: `Has superado tu meta diaria (${metaAlcanzada.toFixed(1)}%). Mantén esta disciplina y constancia.`,
          bgColor: 'bg-success/10 border-success/30'
        };
      case 'warning':
        return {
          icon: <AlertTriangle className="w-6 h-6 text-primary" />,
          title: 'Buen progreso 💪',
          message: `Has alcanzado el ${metaAlcanzada.toFixed(1)}% de tu meta. La disciplina es clave para el éxito consistente.`,
          bgColor: 'bg-primary/10 border-primary/30'
        };
      case 'danger':
        return {
          icon: <AlertCircle className="w-6 h-6 text-destructive" />,
          title: 'Reflexiona sobre tu estrategia ⚠️',
          message: `Solo alcanzaste el ${metaAlcanzada.toFixed(1)}% de tu meta. Revisa tu plan de trading y gestión de riesgo.`,
          bgColor: 'bg-destructive/10 border-destructive/30'
        };
    }
  };

  const resultMessage = getResultMessage();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-muted p-4">
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            onClick={onBack}
            className="text-primary hover:text-primary/80"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-primary">Registro del Día</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6 space-y-8">
        {/* Fecha actual */}
        <Card>
          <CardContent className="p-6 text-center">
            <div className="flex items-center justify-center gap-3 mb-2">
              <Calendar className="w-6 h-6 text-primary" />
              <h2 className="text-xl font-bold text-primary">
                Registro del {currentDate}
              </h2>
            </div>
            <p className="text-muted-foreground">
              {user ? `${user.name}, ingresa` : 'Ingresa'} los datos de cierre de tu sesión de trading
            </p>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Formulario de ingreso */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-primary" />
                Datos de Ingreso
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Saldo inicial (no editable) */}
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Saldo Inicial del Día</Label>
                  <div className="p-3 bg-muted/50 rounded-lg border border-muted">
                    <p className="font-mono text-lg">
                      ${planData.saldoInicial.toLocaleString('es-CL')}
                    </p>
                  </div>
                </div>

                {/* Saldo real (editable) */}
                <div className="space-y-2">
                  <Label htmlFor="saldoReal" className="text-primary font-medium">
                    Saldo Real al Cierre *
                  </Label>
                  <Input
                    id="saldoReal"
                    type="number"
                    step="0.01"
                    value={saldoReal}
                    onChange={(e) => setSaldoReal(e.target.value)}
                    placeholder="Ej: 15907.50"
                    className="text-lg font-mono border-primary/30 focus:border-primary"
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    Ingresa el saldo exacto al cerrar tus posiciones del día
                  </p>
                  {/* Consejo psicológico */}
                  <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <div className="text-sm text-muted-foreground">
                        <strong className="text-primary">Consejo psicológico:</strong> Si tu día va en pérdidas, 
                        registra una cifra aproximada para reducir el impacto emocional. Si tienes ganancias, 
                        registra solo las ganancias para mantener una mentalidad positiva.
                      </div>
                    </div>
                  </div>
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  disabled={!saldoReal}
                >
                  <Calculator className="w-4 h-4 mr-2" />
                  Calcular y Registrar
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Resultados calculados */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-success" />
                Resultados Calculados
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Profit total */}
              <div className="space-y-2">
                <Label className="text-muted-foreground">Profit Total del Día</Label>
                <div className="p-3 bg-success/10 border border-success/30 rounded-lg">
                  <p className="font-mono text-xl text-success font-bold">
                    ${profitTotal.toLocaleString('es-CL')}
                  </p>
                </div>
              </div>

              {/* Profit para retiro */}
              <div className="space-y-2">
                <Label className="text-muted-foreground">
                  Profit Extra para Retiro Diario ({(planData.porcentajeRetiro * 100)}%)
                </Label>
                <div className="p-3 bg-success/5 border border-success/20 rounded-lg">
                  <p className="font-mono text-lg text-success">
                    ${profitRetiro.toLocaleString('es-CL')}
                  </p>
                </div>
              </div>

              {/* Profit para acumulación */}
              <div className="space-y-2">
                <Label className="text-muted-foreground">
                  Profit de Acumulación de Cuenta Real Diaria ({(planData.porcentajeAcumulacion * 100)}%)
                </Label>
                <div className="p-3 bg-success/5 border border-success/20 rounded-lg">
                  <p className="font-mono text-lg text-success">
                    ${profitAcumulacion.toLocaleString('es-CL')}
                  </p>
                </div>
              </div>

              {/* Meta del día (referencia) */}
              <div className="space-y-2">
                <Label className="text-muted-foreground">Meta del Día (Referencia)</Label>
                <div className="p-3 bg-primary/10 border border-primary/30 rounded-lg">
                  <p className="font-mono text-lg text-primary">
                    ${planData.metaDia.toLocaleString('es-CL')}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sección de retiros */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-primary" />
              Control de Retiros
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Pregunta principal */}
            <div className="space-y-3">
              <Label className="font-medium">¿Realizaste algún retiro hoy?</Label>
              <div className="flex gap-4">
                <Button
                  type="button"
                  variant={hizoRetiro === true ? "default" : "outline"}
                  onClick={() => setHizoRetiro(true)}
                  className={hizoRetiro === true ? "bg-primary text-primary-foreground" : "border-primary text-primary hover:bg-primary hover:text-primary-foreground"}
                >
                  Sí
                </Button>
                <Button
                  type="button"
                  variant={hizoRetiro === false ? "default" : "outline"}
                  onClick={() => {
                    setHizoRetiro(false);
                    setMontoRetiro('');
                    setNotasRetiro('');
                    setWithdrawalAlert(null);
                  }}
                  className={hizoRetiro === false ? "bg-muted text-muted-foreground" : "border-muted text-muted-foreground hover:bg-muted hover:text-foreground"}
                >
                  No
                </Button>
              </div>
            </div>

            {/* Formulario de retiro (solo si dijo que sí) */}
            {hizoRetiro === true && (
              <div className="space-y-4 p-4 bg-muted/20 rounded-lg border border-muted">
                <div className="grid md:grid-cols-2 gap-4">
                  {/* Tipo de retiro */}
                  <div className="space-y-2">
                    <Label htmlFor="tipoRetiro">Tipo de Retiro</Label>
                    <Select value={tipoRetiro} onValueChange={(value: 'profit' | 'balance') => setTipoRetiro(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="profit">Solo Profit</SelectItem>
                        <SelectItem value="balance">Balance Total</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      {tipoRetiro === 'profit' 
                        ? 'Solo retiras las ganancias obtenidas' 
                        : 'Retiras parte del capital total (incluye capital inicial)'
                      }
                    </p>
                  </div>

                  {/* Monto */}
                  <div className="space-y-2">
                    <Label htmlFor="montoRetiro">Monto Retirado</Label>
                    <Input
                      id="montoRetiro"
                      type="number"
                      step="0.01"
                      value={montoRetiro}
                      onChange={(e) => setMontoRetiro(e.target.value)}
                      placeholder="Ej: 150.00"
                      className="font-mono border-primary/30 focus:border-primary"
                    />
                  </div>
                </div>

                {/* Notas opcionales */}
                <div className="space-y-2">
                  <Label htmlFor="notasRetiro">Notas (Opcional)</Label>
                  <Textarea
                    id="notasRetiro"
                    value={notasRetiro}
                    onChange={(e) => setNotasRetiro(e.target.value)}
                    placeholder="Ej: Gastos personales, pago de servicios..."
                    className="resize-none h-20 border-primary/30 focus:border-primary"
                    maxLength={200}
                  />
                  <p className="text-xs text-muted-foreground text-right">
                    {notasRetiro.length}/200 caracteres
                  </p>
                </div>

                <Button 
                  onClick={handleWithdrawalSubmit}
                  disabled={!montoRetiro || parseFloat(montoRetiro) <= 0}
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Registrar Retiro
                </Button>
              </div>
            )}

            {/* Badge de confirmación cuando no hay retiro */}
            {hizoRetiro === false && (
              <div className="p-3 bg-success/10 border border-success/30 rounded-lg">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-success" />
                  <span className="text-success font-medium">Sin retiros registrados para hoy</span>
                </div>
              </div>
            )}

            {/* Alertas de retiro */}
            {withdrawalAlert && (
              <Alert className={
                withdrawalAlert.type === 'success' 
                  ? 'bg-success/10 border-success/30' 
                  : 'bg-destructive/10 border-destructive/30'
              }>
                <div className="flex items-start gap-2">
                  {withdrawalAlert.type === 'success' ? (
                    <CheckCircle className="w-4 h-4 text-success mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-destructive mt-0.5" />
                  )}
                  <AlertDescription className={
                    withdrawalAlert.type === 'success' ? 'text-success' : 'text-destructive'
                  }>
                    {withdrawalAlert.message}
                  </AlertDescription>
                </div>
              </Alert>
            )}
          </CardContent>
        </Card>

        <Separator />

        {/* Mensaje de resultado */}
        {showResult && (
          <Alert className={resultMessage.bgColor}>
            <div className="flex items-start gap-3">
              {resultMessage.icon}
              <div className="flex-1">
                <h3 className="font-bold mb-1">{resultMessage.title}</h3>
                <AlertDescription className="text-base">
                  {resultMessage.message}
                </AlertDescription>
              </div>
            </div>
          </Alert>
        )}

        {/* Recordatorio */}
        <Card className="bg-muted/30">
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">
              💡 <strong>Recordatorio:</strong> La constancia en el registro diario te permitirá 
              identificar patrones y mejorar tu performance de trading.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}